<?php
// get user.json directory
$filePath = __DIR__ . '/../data/users.json';
// Get user data
$usersData = file_get_contents($filePath);
$users = json_decode($usersData, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = trim($_POST['name']);
    $name_error = validateName($name);
    $email = $_POST['email'];
    $email_error = validateEmail($email);
    $cell = trim($_POST['cell']);
    $cell_error = validateCell($cell);
    $password = $_POST['password'];
    $password_error = validatePassword($password);
    $hashedPassword = null;

    //hash password
    if ($password_error == null) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    }

    //store data and display success message
    if ($email_error == null && $name_error == null && $cell_error == null && $password_error == null) {
        $newUser = array('name' => $name, 'email' => $email, 'cell' => $cell, 'password' => $hashedPassword, 'type' => 'Client');

        // Append the new user to the existing users array
        $users['user'][] = $newUser;

        // Save the updated user data back to users.json
        if(file_put_contents($filePath, json_encode($users, JSON_PRETTY_PRINT))){
            echo "
                <div class='popup active' id='popup-register'>
                    <div class='overlay' ></div>
                    <div class='content'>
                        <h2>Registration Successful</h2>
                        <a href='/../auth/login.php'>
                            <button> Login</button>
                        </a>
                    </div>
                </div>
            ";
        } 
    }
}

function validateName($name) {
    if (empty(trim($name))) {
        return "*";
    }else
        return null;
}

function validateEmail($email) {
    if (empty(trim($email))) {
        return "*";
    }else 
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return "Invalid email format";
    }else
        return null;
}

function validateCell($cell) {
    if (empty(trim($cell))) {
        return "*";
    } else
    //if number contains spaces or other characters
    if (!preg_match("/^[0-9]*$/", $cell)) {
        return "no spaces or other characters allowed";
    }else
    if (strlen($cell) != 10) {
        return "number must be 10 digits";
    }else
    if (!is_numeric($cell)) {
        return "Invalid cell number";
    }else
        return null;  
}

function validatePassword($password) {
    if (empty(trim($password))) {
        return "*";
    } else
    if (strlen($password) < 8) {
        return "Password must be at least 8 characters long";
    }else
    if (!preg_match("#[0-9]+#", $password)) {
        return "Password must contain at least one number";
    }else
    if (!preg_match("#[A-Z]+#", $password)) {
        return "Password must contain at least one uppercase letter";
    }else
    if (!preg_match("#[a-z]+#", $password)) {
        return "Password must contain at least one lowercase letter";
    }else
    if (!preg_match("#\W+#", $password)) {
        return "Password must contain at least one special character";
    }else
        return null;
}

