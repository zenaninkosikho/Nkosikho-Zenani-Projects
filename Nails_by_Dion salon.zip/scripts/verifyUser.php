<?php
session_start();
$email = null;
$email_error = null;
$password = null;
$password_error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email']) && isset($_POST['password'])) {
        // Sanitize user input
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $password = $_POST['password']; // Assuming password is already hashed 

        // Call the loginUser function
        $user = loginUser($email, $password);

        if ($user !== null) {

            switch ($user['type']) {
                case 'Admin':
                    $_SESSION["user"] = $user;
                    header('Location: ../admin/dashboard.php');
                    exit();
                case 'Client':
                    $_SESSION["user"] = $user;
                    header('Location: ../client/index.php');
                    exit();
                case 'email':
                    $password_error = "Invalid password";
                    break;
                default:
                    $email_error = "Invalid email";
                    break;
            }
        } else {
            $email_error = "Invalid email";
        }
    } else {
        if (empty(trim($_POST['email']))) {
            $email_error = "*";
        } 

        if (empty(trim($_POST['password']))) {
            $password_error = "*";
        }
    }
}

function loginUser($email, $password) {
    // Get user data from users.json
    $filePath = __DIR__ . '/../data/users.json';
    $usersData = file_get_contents($filePath);
    $users = json_decode($usersData, true);
    $valid['type'] = null;

    if ($users !== null) { // Check if data was successfully decoded
        foreach ($users['user'] as $user) {
            if ($user['email'] === $email && password_verify($password, $user['password'])) {   
                return $user; // Return the user if found
            }

            if ($user['email'] === $email) {
                $valid['type'] = 'email';
            }
        }
    }else {
        echo "<script>alert('Error reading data.');</script>";
    }

    if ($valid['type']===null) {
        return null;
    }else
        if ($valid['type'] !== null) {
            return $valid;
        }
}