<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="/../styles/client_styles.css">
    <link rel="stylesheet" href="/../styles/main_styles.css">
    <link rel="stylesheet" href="/../styles/style.css">
    <script src="../scripts/appointFunction.js" ></script>
</head>
<body>
    <?php $page = 'services'; include '../partial/header.php';?>

    <div id="popupBack" class="popupBackground"><!--popup background-->

<div class="popupBlock"  ><!--popup block-->
    
    <div class="contentblock">
    <h2 class='headingCol'>heading</h2>

        <p  class='tableHeading'>This will be the description of the service selected by a user</p>
        <table class='dialogServicesInfo'>
            
            <tr class='detailsRow'>
                <td class='dialogServiceCell'>
                    <img id='thumbnailDialog' class='dialogThumbnail' src="../_images\10.jpg" >
                </td>
                <td class='dialogDescriptionCell'>
                    
                    <table class ='dialogInfoTable'>
                        
                        <tr>
                            <td class='serviceDetailCellH'>Price</td>
                            <td class='serviceDetailCellH'>duration</td>
                            <td class='serviceDetailCellH' >time</td>
                            <td class='serviceDetailCellH' >
                                <p class='tableHeadingRed'>
                                    Sessions Required
                                </p>
                            </td>   
                        </tr>
                        <tr>
                            <td class='serviceDetailCell'>R 100.00</td>
                            <td class='serviceDetailCell'>2 hrs</td>
                            <td class='serviceDetailCell'>14:30</td>
                            <td class='serviceDetailCell'>
                            <table class='sessionTable'>
                                <tr>
                                    <td class='sessionCol'>
                                    
                                    <div class='addButtonDialog' class='addButtonDialog' id='unitDecrement' onclick='myController.changeSessions(false,1)'>-</div>

                                    </td>
                                    <td class='sessionColvalue' id='sessionValue'>1</td>
                                    <td class='sessionCol'>
                                        <div class='addButtonDialog' id='unitIncrement' onclick='myController.changeSessions(true)'>+</div>
                                        
                                    </td>
                                </tr>
                            </table>
                            </td>   
                        </tr>
                    </table>
                </td>
                <td class='headingCol'>
                
                            
                        
                    
                </td>
            </tr>
        </table>


                    <table class='timeTable'>
                            
                            <tr>
                                <td class='incTime' onclick='newformatter.incDay()'>
                                    <div class='incButton' >+</div>
                                </td>
                                <td class='incTime' onclick='newformatter.incMonth()'><div class='incButton'>+</div></td>
                                <td class='incTime'><div class='incButton'>+</div></td>
                                <td class='spaceBlock'></td>
                                <td class='incTime'><div class='incButton'>+</div></td>
                                <td class='incTime'><div class='incButton'>+</div></td>
                                <td class='incTime'><div class='incButton'>+</div></td>   
                            </tr>
                            <tr>
                                <td id='day' class='timeBlock'>19</td>
                                <td id='month' class='timeBlock'>Jan</td>
                                <td class='timeBlock'>2024</td>
                                <td class='spaceBlock'></td>
                                <td class='timeBlock'>18</td>
                                <td class='timeBlock'>:</td>
                                <td class='timeBlock'>48</td>                                   
                            </tr>
                            <tr>
                                <td class='redtime'><div class='incButton'>-</div></td>
                                <td class='redtime'><div class='incButton'>-</div></td>
                                <td class='redtime'><div class='incButton'>-</div></td>
                                <td class='spaceBlock'></td>
                                <td class='redtime'><div class='incButton'>-</div></td>
                                <td class='redtime'><div class='incButton'>-</div></td>
                                <td class='redtime'><div class='incButton'>-</div></td>                                   
                            </tr>
                        </table>
                
                

        
        <button id='closePopup' class="closePopupAppointments" onclick='newformatter.removePop()'>Close</button>

    </div>

<table id='lastButtons'>
    <tr>
        <td>
        </td>
            
        <td>
        
        </td>
    </tr>
</table>

</div>

</div>

</div>



    <script>


        var newformatter= new formatter(); 
        newformatter.showStatus();
        newformatter.showAppointments();
        //newformatter.runPopup();
        //newformatter.addEventListener("click", function () { newformatter.removePop(); });

    
    </script>
    <?php include '../partial/footer.php';?>    

    
</body>
</html>