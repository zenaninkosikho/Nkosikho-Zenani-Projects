<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="/../styles/client_styles.css">
    <link rel="stylesheet" href="/../styles/main_styles.css">
    <link rel="stylesheet" href="/../styles/style.css">
    <script src="../scripts/client_script.js" defer></script>
    <script src="../scripts/serviceFunction.js" ></script>
</head>
<body>
    <?php /*$page = 'home'; include '../partial/header.php';*/?>
    <?php $page = 'services'; include '../partial/header.php';?>
    <br>
	<img src="_images\logo.png" id="shortlisted" onclick="myController.showPop(1)">

    <div id="serviceList">

    <div id='noticeBox' class='notice'>
        <p id='externalMsg'class='noticeMessage'></p>
    </div>

    <h3 class='serviceCategories'>Eyebrows</h3>

    <table class=serviceTable>
        <tr>
            <td class='gridBlockImage'>
                <img src="../_images/1.jpg" width="150" height="150" class='gridImage' onclick="myController.showPop(1)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Classic</p><p class='price'> R400.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'>
                            <div class='addButton' onclick='myController.bookService(1, false)'>+</div>
                        </td>
                    </tr>
                </table>
            </td>
            
            <td class='gridBlockImage'>
                <img src="../_images\2.jpg" width="150" height="150" class='gridImage' onclick="myController.showPop(2)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Hybrid</p><p class='price'> R500.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'>
                            <div class='addButton' onclick='myController.bookService(2,false)'>+</div>
                        </td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\3.jpg" width="150" height="150" class='gridImage' onclick="myController.showPop(3)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Strip Las</p><p class='price'> R450.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(3, false)'>+</div></td>
                    </tr>
                </table>
            </td>


            <td class='gridBlockImage'>
                <img src="../_images\20.png" width="150" height="150" class='gridImage' onclick="myController.showPop(4)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Volume</p><p class='price'> R600.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(4, false)'>+</div></td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\21.jpg" width="150" height="150" class='gridImage' onclick="myController.showPop(5)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Mega Vol</p><p class='price'> R800.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(5, false)'>+</div></td>
                    </tr>
                </table>
            </td>


        
            </td class='gridBlock'>
        </tr>
       
    </table>

    
    <br>

    <h3 class='serviceCategories'>Nails</h3>
    <table class=serviceTable>
        <tr>
            <td class='gridBlockImage'>
                <img src="../_images\4.png" width="150" height="150" class='gridImage' onclick="myController.showPop(6)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'>
                            <p id="sDetails" class='serviceLabel' >
                                <p id="sDetails" class='serviceLabel'>Nail Art</p>
                                <p class='price'> R30.00</p>
                            </p>
                            
                        </td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(6, false)'>+</div></td>
                    </tr>
                </table>
            </td>
            
            <td class='gridBlockImage'>
                <img src="../_images\5.png" width="150" height="150" class='gridImage' onclick="myController.showPop(7)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Acrylic</p><p class='price'> R420.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(7, false)'>+</div></td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\6.png" width="150" height="150" class='gridImage' onclick="myController.showPop(8)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Gel</p><p class='price'> R370.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(8, false)'>+</div></td>
                    </tr>
                </table>
            </td>


            <td class='gridBlockImage'>
                <img src="../_images\14.png" width="150" height="150" class='gridImage' onclick="myController.showPop(9)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Silk</p><p class='price'> R390.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(9, false)'>+</div></td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\16.png" width="150" height="150" class='gridImage' onclick="myController.showPop(10)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Soak off</p><p class='price'> R130.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(10, false)'>+</div></td>
                    </tr>
                </table>
            </td>


        
            </td class='gridBlock'>
        </tr>
       
    </table>
    
    <h3 class='serviceCategories'>Hair</h3>
    <table class=serviceTable>
        <tr>
            <td class='gridBlockImage'>
                <img src="../_images\17.png" width="150" height="150" class='gridImage' onclick="myController.showPop(11)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Knotless</p><p class='price'> R850.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>
            
            <td class='gridBlockImage'>
                <img src="../_images\19.png" width="150" height="150" class='gridImage' onclick="myController.showPop(12)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Small</p><p class='price'> R900.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\18.png" width="150" height="150" class='gridImage' onclick="myController.showPop(13)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Medium</p><p class='price'> R800.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>


            <td class='gridBlockImage'>
                <img src="../_images\7.png" width="150" height="150" class='gridImage' onclick="myController.showPop(14)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Large</p><p class='price'> R750.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\8.png" width="150" height="150" class='gridImage' onclick="myController.showPop(15)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Thick</p><p class='price'> R700.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>


        
            </td class='gridBlock'>
        </tr>
       
    </table>

    <h3 class='serviceCategories'>Waxing</h3>
    <table class=serviceTable>
        <tr>
            <td class='gridBlockImage'>
                <img src="../_images\23.jpeg" width="150" height="150" class='gridImage' onclick="myController.showPop(16)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Full Body</p><p class='price'> R110.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>
            
            <td class='gridBlockImage'>
                <img src="../_images\24.jpeg" width="150" height="150" class='gridImage' onclick="myController.showPop(17)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Underarms</p><p class='price'> R120.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\12.jpg" width="150" height="150" class='gridImage' onclick="myController.showPop(18)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Bikini</p><p class='price'> R160.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>


            <td class='gridBlockImage'>
                <img src="../_images\10.jpg" width="150" height="150" class='gridImage' onclick="myController.showPop(19)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Brazilian</p><p class='price'> R335.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>

            <td class='gridBlockImage'>
                <img src="../_images\11.jpg" width="150" height="150" class='gridImage' onclick="myController.showPop(20)">            
                <table class='labelTable'>
                    <tr >
                        <td class='labelTableCell'><p id="sDetails" class='serviceLabel' ><p id="sDetails" class='serviceLabel'>Face</p><p class='price'> R225.00</p></p></td class='gridBlock'></td>
                        <td class='labelTableCellAdd'><div class='addButton' onclick='myController.bookService(1, false)'>+</div></td>
                    </tr>
                </table>
            </td>


        
            </td class='gridBlock'>
        </tr>
       
    </table>
    <br>
    <br>
    <br>
</div>
    
<div id="popupBack" class="popupBackground"><!--popup background-->

<div class="popupBlock"  ><!--popup block-->
    
    <div class="contentblock">
    <h2 id='serviceName' class='headingCol'>heading</h2>
    <p id='description' class='tableHeading'>This will be the description of the service selected by a user</p>
        <table class='dialogServicesInfo'>
            
            <tr class='detailsRow'>
                <td class='dialogServiceCell'>
                    <img id='thumbnailDialog' class='dialogThumbnail' src="../_images\10.jpg" >
                </td>
                <td class='dialogDescriptionCell'>
                    
                    <table class ='dialogInfoTable'>
                        
                        <tr>
                            <td class='serviceDetailCellH'>Price</td>
                            <td class='serviceDetailCellH'>Duration</td>
                            <td class='serviceDetailCellH' >Time</td>
                            <td class='serviceDetailCellH' >
                                <p class='tableHeadingRed'>
                                    Sessions Required
                                </p>
                            </td>   
                        </tr>
                        <tr>
                            <td id='price' class='serviceDetailCell'>R 100.00</td>
                            <td id='duration' class='serviceDetailCell'>2 hrs</td>
                            <td  class='serviceDetailCell'>14:30</td>
                            <td class='serviceDetailCell'>
                            <table class='sessionTable'>
                                <tr>
                                    <td class='sessionCol'>
                                    
                                    <div class='addButtonDialog' class='addButtonDialog' id='unitDecrement' onclick='myController.changeSessions(false,1)'>-</div>

                                    </td>
                                    <td class='sessionColvalue' id='sessionValue'>1</td>
                                    <td class='sessionCol'>
                                        <div class='addButtonDialog' id='unitIncrement' onclick='myController.changeSessions(true)'>+</div>
                                        
                                    </td>
                                </tr>
                            </table>
                            </td>   
                        </tr>
                    </table>
                </td>
                <td class='headingCol'>
                
                            
                        
                    
                </td>
            </tr>
        </table>

                    <table class='mainStylistTable'>
                            <tr>
                                <td>
                                    <table id='dialogStylistTable1' class='dialogStylistTable' onclick='myController.markStylist(1)'>
                                        <tr>
                                            <td class='dialogStylistCell'>
                                                <img class='stylistThumbnail' src="../_images\7.png"  width="20">
                                            </td>    
                                        </tr>
                                        <tr>
                                            <td id='Stylist1' class='dialogStylistCell'>Dion</td>

                                        </tr>
                                    </table >
                                </td>
                                <td>
                                    <table id='dialogStylistTable2' class='dialogStylistTable' onclick='myController.markStylist(2)'>
                                        <tr>
                                            <td class='dialogStylistCell'>
                                                <img class='stylistThumbnail' src="../_images\4.png"  width="20">
                                            </td>  
                                        </tr>
                                        <tr>
                                            <td id='Stylist2' class='dialogStylistCell'>Thando</td>
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table id='dialogStylistTable3' class='dialogStylistTable' onclick='myController.markStylist(3)'>
                                        <tr>
                                            <td class='dialogStylistCell'>
                                                <img class='stylistThumbnail' src="../_images\2.jpg"  width="20">
                                            </td>   
                                        </tr>
                                        <tr>
                                            <td id='Stylist3' class='dialogStylistCell'>Mpho</td>
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table id='dialogStylistTable4' class='dialogStylistTable' onclick='myController.markStylist(4)'>
                                        <tr>
                                            <td class='dialogStylistCell'>
                                                <img class='stylistThumbnail' src="../_images\4.png"  width="20">
                                            </td>   
                                        </tr>
                                        <tr>
                                            <td id='Stylist4' class='dialogStylistCell'>Sipho</td> 
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table id='dialogStylistTable5' class='dialogStylistTable' onclick='myController.markStylist(5)'>
                                        <tr>
                                            <td class='dialogStylistCell'>
                                                <img class='stylistThumbnail' src="../_images\4.png"  width="20">
                                            </td>   
                                        </tr>
                                        <tr>
                                            <td id='Stylist5' class='dialogStylistCell'>Sizwe</td> 
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table id='dialogStylistTable6' class='dialogStylistTable' onclick='myController.markStylist(6)'>
                                        <tr>
                                            <td class='dialogStylistCell'>
                                                <img class='stylistThumbnail' src="../_images\4.png"  width="20">
                                            </td>   
                                        </tr>
                                        <tr>
                                            <td id='Stylist6' class='dialogStylistCell'>Vusi</td> 
                                        </tr>
                                    </table>
                                </td>
                                
                               
                                   
                            </tr>
                    </table>
                    <p id='internalMsg' class='tableHeading'>.</p>
    
                    
                    
                    
                    
                
           

        
        <button id='buttonBook' class="bookButton" >Book</button>

        <button id='closePopup' class="closePopup" >Close</button>

    </div>

<table id='lastButtons'>
    <tr>
        <td>
        </td>
            
        <td>
        
        </td>
    </tr>
</table>

</div>

</div>
    
    <script>

        myController=new controller();
        
        shortlisted.addEventListener("click", function () { myController.showPop(); });
        closePopup.addEventListener("click", function () { myController.removePop();});
        window.addEventListener("click", function (event) {myController.removeByBackground();});

        var hasBeenClearedForStart=false;

        
           //sessionStorage.clear();
        
    </script>
		
    
    <?php include '../partial/footer.php';?>
</body>
</html>