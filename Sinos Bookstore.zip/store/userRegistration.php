<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
       
        <h>Register as a user</h>
        <br>
        <br>
        <p>Welcome to the registration page </h>

        <form method="post">
            <p>Name</p>
            <input id="nameReg" type="text" name="nameRegistration">
            <br>
            <br>

            <p>Email</p>
            <input id="emailReg" type="text" name="emailRegistration">
            <br>
            <br>

            <p>Student Number</p>
            <input id="numberReg" type="text" name="numberRegistration">
            <br>
            <br>

            <p>Password</p>
            <input id="passwordReg" type="text" name="passwordRegistration">
            <br>
            <br>

            <button id="signUp" >Sign Up</button>
        </form>
        <br>

        
            <?php 
                include('DBConn.php');
                $name;
                $userName;
                $studentNumber;
                $password;
                $userExists;

                if($_SERVER["REQUEST_METHOD"]=="POST")
                {
                    //get form data
                    $name=htmlspecialchars($_POST["nameRegistration"]);
                    $email=htmlspecialchars($_POST["emailRegistration"]);
                    $studentNumber=htmlspecialchars($_POST["numberRegistration"]);
                    $password=htmlspecialchars($_POST["passwordRegistration"]);
                    //$message=htmlspecialchars($_POST["mes"]);
                    

                
                
                    if(strlen($userName)==0 || strlen($studentNumber)==0 || strlen($password)==0)
                    {
                        echo'<p id="resultant">', 'Please check the password OR USER NAME','</p>';
                    }

                    if(strpos($studentNumber,'st')!==false)//strlen($studentNumber)>=5
                    {
                        //check if exists
                        $userExists=false;
                        

                        //compare form data with database data
                                //the query
                                $query="select name_,email, hashcode from tblUser where name_='$name'";
                                
                                //result from the query
                                $result=$con->query($query);
                                
                                //looping on array returned by result
                                while($row=$result->fetch_assoc())
                                {
                                    $someword=' thando booi';
                                    if($row['name_']===$name)
                                    {
                                        
                                        $userExists=true;
                                        //displaying
                                        break;
                                    }
                                        
                                    
                                }
                        
                        if($userExists===true)//$studentNumber==='st1023'
                        {
                            header("Location:../userRegistraton.php");
                            
                        }else if($userExists===false)
                        {
                            /*save the credentials*/
                            
                            //hash the password
                            
                            //Password hashing registration
                            //$userpassword='this_is_a_password';
                            $options=['cost'=>12,];
                            $hashedpassword= password_hash($password, PASSWORD_BCRYPT, $options);

                            //insert into a table
                                //check if insert data exists , if true cancel
                                $insertData="insert into pendingusers values
                                (userId,'$name', '$email', '$hashedpassword');
                                ";
                                
                                if($con->query($insertData)===true)
                                {
                                    echo"<p>ALL DONE! THANK YOU FOR REGISTERING. YOUR ACCOUNT IS NOW PENDING.</p>";

                                }else
                                {
                                    $con->error;
                                }
                    
                        }
                        echo '<br>';
                        //echo'<a href=usesystemlogin.php>BACK TO USER LOGIN     &nbsp;</a>';

                    }else
                    {
                        //header("Location:../userRegistraton.php");
                            
                    }
                }
                //logic to check form- ESTABLISHED
               /* if(key_exists("emailRegistration",$_POST))
                {
                    $enteredEmail=$_POST["emailRegistration"];

                    if($enteredEmail=="dx")
                    {
                        header("Location:../forms.php");
                    }
                    else
                    {
                        echo'<p id="resultant">', 'Please check the password','</p>';
                        
                    }
                }*/

                echo '<a href=userLogin.php>BACK TO USER LOGIN     &nbsp;</a>';

            ?>
            
            <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,a
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                #nameReg, #emailReg, #numberReg, #passwordReg
                {
                    background-color:rgb(238, 242, 246) ;
                    font-size: 10px;
                    color: black;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 10%;
                    margin-left: 36%;
                }

                h,p,button,a
                {
                    margin-left: 36%;
                }

                button
                {
                    
                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

            </style>
 
                
    </body>
</html>