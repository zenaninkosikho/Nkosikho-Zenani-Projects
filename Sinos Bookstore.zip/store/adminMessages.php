<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
        

        <form method="post">
            <p>Sell books 
 
                <a href=adminDash.php>Back to Dashboard</a>
            </p>	

        </form>
   
        <br>
        <h>Messages to buyers and sellers</h>
        <br>
        <br>

        <form method="POST" action='adminMessages.php'>
            <input name= messagefield type='input'><br><br>
            <button>send Message</button>
        </form>

        <?php 
            
            include('DBConn.php');
            if(key_exists('messagefield',$_POST)==true)
            {
                $uploadMessage="insert into mbuyerssellers values("."'".$_POST['messagefield']."'".");";
                $con->query($uploadMessage);
                echo'message sent';
            }
        //reason you initially get an error is because 'name' does not exist in global array
        //maybe for this one you need to find if you can post on the superglabal directly first
           
            if(key_exists("newName9", $_POST)==true)
            {
                //using HTML directly, you get error because as the page loads
                //a none existent key is referenced
                $inputData=$_POST["newName9"];
                echo "data in InputData: ", $inputData;
                
                echo '<p id="draggedString">',  $GLOBALS["inputData"],'</p>';
            }else
            {
                
            }            
        ?>

        <?php //echo '<button id="dragText" >Drag</button>';?>
        <script>
            //dragText.addEventListener('click', function()
            {
                var collectedText=document.getElementById("draggedString").innerHTML;
                document.getElementById("draggedString").textContent=collectedText+" plus more text";
            } ;//);
        </script>
                    <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,a
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                input, #deleteUserID, #addBookID, #updateBookID, #deleteBookId
                {
                    background-color:rgb(238, 242, 246) ;
                    color: black;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 0%;
                    margin-left: 16%;
                }

                h,p,button,#dashLinks,a
                {
                    margin-left: 16%;
                }

                button
                {
                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

                #allUsersVerifiedMsg
                {
                    color: grey;
                    margin-left: 20%;
                    font-style: italic;
                    font-size: 10px;
                }

            </style>
        
    </body>
</html>