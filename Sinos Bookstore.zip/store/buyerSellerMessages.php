<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
        

        <form method="post">
            <p>Buyer Messages
                <a href=store.php>Back to store</a>
            </p>	

        </form>
        <br>

        <?php 

            echo "<section>
            <table>
                <tr>
                    <th>Messsages</th>
                
                </tr>

            ";    //PHP CODE TO FETCH DATA FROM ROWS -->

            /*     <th>Book Title</th>
                    <th>available_copies</th>
                    <th>Price</th>*/ 

                include('DBConn.php');

                // SQL query to select data from database
                $sql2=" select * from mbuyerssellers; ;";
                //result from the query
                $result=$con->query($sql2);
                //$mysqli->close();

                $result=$con->query($sql2);
                
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
                    

                echo"
                    <tr>
                        <!-- FETCHING DATA FROM EACH
                            ROW OF EVERY COLUMN -->
                            <td>",  $rows['message'],"</td>
                                
                                
                    </tr>
                    ";
                    //<td>",  $rows['title'],"</td>
                    //<td>",  $rows['available_copies'],"</td>
                    //<td>", "R" ,$rows['price'],"</td>
                }

                echo "<h>Admin & Customer messages</h>
                <br>
                <br>";
                
        ?>


        <?php 
        //reason you initially get an error is because 'name' does not exist in global array
        //maybe for this one you need to find if you can post on the superglabal directly first
           
            if(key_exists("newName9", $_POST)==true)
            {
                //using HTML directly, you get error because as the page loads
                //a none existent key is referenced
                $inputData=$_POST["newName9"];
                echo "data in InputData: ", $inputData;
                
                echo '<p id="draggedString">',  $GLOBALS["inputData"],'</p>';
            }else
            {
                
            }            
        ?>

        <?php //echo '<button id="dragText" >Drag</button>';?>
        <script>
            //dragText.addEventListener('click', function()
            {
                var collectedText=document.getElementById("draggedString").innerHTML;
                document.getElementById("draggedString").textContent=collectedText+" plus more text";
            } ;//);
        </script>
                    <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,a
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                #deleteUserID, #addBookID, #updateBookID, #deleteBookId
                {
                    background-color:rgb(238, 242, 246) ;
                    color: aquamarine;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 0%;
                    margin-left: 16%;
                }

                h,p,button,#dashLinks,a
                {
                    margin-left: 16%;
                }
                
                button
                {
                   
                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

                #allUsersVerifiedMsg
                {
                    color: grey;
                    margin-left: 20%;
                    font-style: italic;
                    font-size: 10px;
                }

            </style>
            <style>
                
                

                table 
                {
                    margin-left: 15%;
                    font-family: 'Lucida Sans';
                    width: 50%;
                }

                td 
                {
                    background-color: ghostwhite;
                    width: 15%;
                }

                #cartTable
                {
                    background-color: white;
                    color: white;
                    
                }

                th,td 
                {
                    font-weight: bold;
                    /*border: 1px solid black;*/
                    padding: 10px;
                    text-align: center;
                }

                td 
                {
                    font-weight: lighter;
                }

            </style>
        
    </body>
</html>