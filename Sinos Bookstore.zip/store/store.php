<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Store</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">


    <?php 
        class store
        {

            public function showHeader()
            {
                echo
                "
                <h>welcome to the Areads</h>
                <br>
                <br>
                <!--<div id=navbar>-->
                <a href=cart.php>Cart</a>
                <a href=buyerSellerMessages.php>Chat</a>
                <a href=sellBooks.php>Sell</a>
                <a href=userLogin.php>Logout</a>
                <!--</div>-->
                <br>
                <br>
                    <p>Search 
                        <input id='search' type='text' name='searchBook'>
                        <button>search</button>
                    </p>
                <br>
                <h>Available Books</h>
                <br>
                <br>
                ";
            }

            public function checkBookExistence()
            {
                 //reason you initially get an error is because 'name' does not exist in global array
                 //maybe for this one you need to find if you can post on the superglabal directly first
                include('DBConn.php');
                //include('createTable.php');//to reset as the webpage is loaded
                //include('loadBookStore.php');
                
                if(key_exists("searchBook", $_POST)==true)
                {
                    //using HTML directly, you get error because as the page loads
                    //a none existent key is referenced
                    $searchedData=$_POST["searchBook"];
                    echo "data in search box: ", $searchedData;
                    
                    echo '<p id="draggedString">',  $GLOBALS["searchedData"],'</p>';
                }else
                {
                
                }   
            }

            public function createUsersTable()
            {
                //create table
			    include('DBConn.php');
				
				$exists =mysqli_connect_error(/*$con, "select 1 from tblUser"*/);
				
                    if($exists!==false)
                    {
                        $delete= mysqli_query($con, "drop table tblUser");
                        //echo "table dropped";
                        
                        $table_create = "create table tblUser(userId int auto_increment primary key,
                                        name_ varchar(20), 
                                        email varchar(50), 
                                        hashcode varchar(100));";
                                        
                        if($con->query($table_create)=== true)
                        {
                            //echo "Table recreated successfully";
                        }else
                        {
                            echo "Error creating table".$con->error;
                        }
                        $serverName="localhost";
                        $userName="root"; 
                        $password="";
                        $dbName="bookstore";
    
                        mysqli_query($con, "set global local_infile=1");
                        mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblUser.txt' into table tblUser fields
                        terminated by ',' lines terminated by '\n';") 
                         or  die('Error loading data file.<br>'.mysqli_error($con));
                    }else
                    {
                        echo("This table does not exist");
                    }
            }

            public function loadBookStoreTables()
            {
                //load bookstore
				include('DBConn.php');
				
				$exists =mysqli_connect_error(/*$con, "select 1 from tblUser"*/);
                    /*$exist2=mysql_query("select 1 from tblUser limit 1");
                    if(mysql_query("describe tblUser"))
                    {
                        
                    }*/
                    
                    if($exists!==false)
                    {
                        $delete= mysqli_query($con, "drop table tblUser");
                        //echo "table dropped";
                        echo '<br>';
                        $create_tblUser= "create table if not exists tblUser(userId int auto_increment primary key,
                                          name_ varchar(20), 
                                          email varchar(50), 
                                          hashcode varchar(100), 
                                          seller int default 0);";
                        
                        $delete= mysqli_query($con, "drop table tblAdmin");
                        //echo "table dropped";
                        $create_tblAdmin= "create table if not exists tblAdmin(adminId int auto_increment primary key, 
                                           name_ varchar(20));";
                        
                        //$delete= mysqli_query($con, "drop table tblorder");
    
                        //echo "table dropped";
                        $create_tblBooks= "create table if not exists tblBooks(bookId int auto_increment primary key, 
                                           title varchar(50), 
                                           available_copies int, price int); ";
                        
                        $delete= mysqli_query($con, "drop table tblBooks");
                        //echo "table dropped";															
                       // $create_tblorder= "create table if not exists tblorder(orderName varchar(50) , orderUnits int, 
                          //                  bookId int ,orderdate date);"; 
                        
                        if($con->query($create_tblUser)=== true)
                        {
                            //echo "Table recreated successfully";
                        }else
                        {
                            echo "Error creating table".$con->error;
                        }
                        
                        if($con->query($create_tblAdmin)=== true)
                        {
                            //echo "Table recreated successfully";
                        }else
                        {
                            echo "Error creating table".$con->error;
                        }
                        
                        if($con->query($create_tblBooks)=== true)
                        {
                            //echo "Table recreated successfully";
                        }else
                        {
                            echo "Error creating table".$con->error;
                        }
                        
                        //if($con->query($create_tblorder)=== true)
                        {
                            //echo "Table recreated successfully";
                        }//else
                        {
                           // echo "Error creating table".$con->error;
                        }
    
                    $serverName="localhost";
                    $userName="root";
                    $password="";
                    $dbName="bookstore";
    
                        mysqli_query($con, "set global local_infile=1");
                        mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblUser.txt' into table tblUser fields
                        terminated by ',' lines terminated by '\n';") 
                         or  die('Error loading data file.<br>'.mysqli_error($con));
                         
                        mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblAdmin.txt' into table tblAdmin fields
                        terminated by ',' lines terminated by '\n';") 
                         or  die('Error loading data file.<br>'.mysqli_error($con));
                        
                        mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblBooks.txt' into table tblBooks fields
                        terminated by ',' lines terminated by '\n';") 
                         or  die('Error loading data file.<br>'.mysqli_error($con));
                        
                        /*mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblorder.txt' into table tblorder fields
                        terminated by ',' lines terminated by '\n';") 
                         or  die('Error loading data file.<br>'.mysqli_error($con));*/
                    }else
                    {
                        echo("This table does not exist");
                    }
                    
                    //echo "THIS IS THE LOAD BOOKSTORE PAGE";
            }

            public function showBooksTable()
            {
                /*echo"         
                    <section>
                    <table>
                        <tr>
                            <th>bookId</th>
                            <th>Book Title</th>
                            <th>available_copies</th>
                            <th>Price</th>
                        </tr>

                    "; */   //PHP CODE TO FETCH DATA FROM ROWS -->

                     
        
                        include('DBConn.php');

                        // SQL query to select data from database
                        //bookId,title,available_copies,price
                        $sql2=" select * from tblbooks ;";
                        //result from the query
                        $result=$con->query($sql2);
                        //$mysqli->close();

                        $result=$con->query($sql2);
                        
                        // LOOP TILL END OF DATA
                        while($rows=$result->fetch_assoc())
                        {
                            

                        /*echo"
                            <tr>
                                <!-- FETCHING DATA FROM EACH
                                    ROW OF EVERY COLUMN -->
                                       <td>",  $rows['bookId'],"</td>
                                        <td>",  $rows['title'],"</td>
                                        <td>",  $rows['available_copies'],"</td>
                                        <td>", "R" ,$rows['price'],"</td>
                            </tr>
                            ";*/
                            
                        }
                    

                                    
                        echo        "</table>
                            </section>
                            ";

            }

            public function showBooks()
            {
                
                //arrage all element in the table designed
                //integrate this text into the loop above, image will be fetch by function
                include('DBConn.php');
                echo"

                <table>
                    <tr>
                        <th></th>
                        <th>Book Name</th>
                        <th>Price</th>
                        <th>Option</th>
                    </tr>
                    <tr>
                        <td><img src='Images\physio.png' height='100' width='auto'></td>
                        <td><p> item nphysioame</p></td>
                        <td><button id='myButton'>View Popup</button></td>
                        <td><a href='store.php?addButton=cartInsert' ><button> Add to cart</button></a>
                        <a href='cart.php' ><button> View cart</button></a></td>
                    </tr>

                <form method='POST' action=store.php>
                    <input name = 'hiddenInput' type='hidden'>
                    <!--<button id='myCartButton' name='cartButton'>Add to Cart</button>-->
                </form>";
                
                //check if exists, if does not, add, if it does update units
                //move this into its own function that takes parameters, button number to increment
                $bookExists=false;
                if(key_exists('addButton', $_GET)==true)
                {
                
                //compare form data with daatabase data
                        //the query
                        $searchQuery="select orderName from tblorder where orderName='Physio Touch'";
                        
                        //result from the query
                        $result=$con->query($searchQuery);
                        
                        //looping on array returned by result
                        while($row=$result->fetch_assoc())
                        {
                            $someword=' thando booi';
                            if($row['orderName']==='Physio Touch')
                            {
                                
                                $bookExists=true;
                                
                                break;
                            }
                        }
                
                }
                if($bookExists===true)
                {
                    //update book units
                    if(key_exists('addButton', $_GET)==true)
                    {
                        $updateQuery='update tblorder set orderUnits=orderUnits+ '. 1 ." WHERE orderName='Physio Touch'";
                        //$con->query($updateQuery);
                        //run the query 
                        if($con->query($updateQuery)===true)
                        {
                            //echo"added to cart";
                            
                        }else
                        {
                            $con->error;
                        }

                    }

                }else if($bookExists===false)
                {
                    if(key_exists('addButton', $_GET)==true)
                    {
                        //insert book
                        $insertData="insert into tblorder values('Physio Touch',1, 1, '2023-09-02',850);";
                        

                        //run the query 
                        if($con->query($insertData)===true)
                        {
                            //echo"added to cart";
                            
                        }else
                        {
                            $con->error;
                        }

                        
                    }
                    
                    //add to cart history
                    //add to orderline

                    //write to order line table and history
                            //$insertData="insert into orderline values(".$row['orderName'].",".$row['orderUnits'].",". $row['bookId'].",". $row['orderdate'].",".$row['price'].");";
                            
                            if(key_exists('orderline2', $_GET)==true)
                            {
                                
                            }
                }
                //add to cart, by writing in orders
                //at the bottom of cart add button to clear the whole cart (delete table query)
                
                    


                if(key_exists('cartButton', $_GET)==true)
            {
                    //if($_GET['addButton']=='cartInsert')
                    {
                        //insert into orders table
                    }
            }

            
            //show popup
            echo"
                    <div id='myPopup' class='popup'  width ='400' height='90'>
                        
                    <div class='popup-content'  width ='400' height='90'>
                        <p>The price is R 850</p>
                        <button id='closePopup'>Close</button>

                    </div>
                    
                        <script>
                            myButton.addEventListener('click', function () 
                            {
                                myPopup.classList.add('show');
                            });

                            closePopup.addEventListener('click', function () 
                            {
                                myPopup.classList.remove('show');
                            });

                            window.addEventListener('click', function (event) 
                            {
                                if (event.target == myPopup) 
                                {
                                    myPopup.classList.remove('show');
                                }
                            });
                        </script>


                </div>";

                echo"
        
        <tr>
            <td><img src='Images\good_game.png' height='100' width='auto'></td>
            <td><p> item name</p></td>    
            <td><button id='myButton1'>View Price</button></td>
            <td> <a href='store.php?addButton2=cartInsert' ><button> Add to cart</button></a>
            <a href='cart.php' ><button> View cart</button></a></td>
        </tr>
   
       
        <div id='myPopup1' class='popup'  width ='400' height='90'>

            <div class='popup-content'  width ='400' height='90'>     
                <p>The price is R 530</p>
                <button id='closePopup1'>Close</button>
            </div>
            
                <script>
                    myButton1.addEventListener('click', function () 
                    {
                        myPopup1.classList.add('show');
                    });

                    closePopup1.addEventListener('click', function () 
                    {
                        myPopup1.classList.remove('show');
                    });

                    window.addEventListener('click', function (event) 
                    {
                        if (event.target == myPopup1) 
                        {
                            myPopup1.classList.remove('show');
                        }
                    });
                </script>
        </div>

        ";

        //check if exists, if does not, add, if it does update units
        $bookExists=false;
        if(key_exists('addButton2', $_GET)==true)
        {
        
        //compare form data with daatabase data
                //the query
                $searchQuery="select orderName from tblorder where orderName='The Good Game'";
                
                //result from the query
                $result=$con->query($searchQuery);
                
                //looping on array returned by result
                while($row=$result->fetch_assoc())
                {
                    $someword=' thando booi';
                    if($row['orderName']==='The Good Game')
                    {
                        
                        $bookExists=true;
                        
                        break;
                    }
                }
        
        }
        if($bookExists===true)
        {
            //update book units
            if(key_exists('addButton2', $_GET)==true)
            {
                $updateQuery='update tblorder set orderUnits=orderUnits+ '. 1 ." WHERE orderName='The Good Game'";
                //$con->query($updateQuery);
                //run the query 
                if($con->query($updateQuery)===true)
                {
                    //echo"added to cart";
                    
                }else
                {
                    $con->error;
                }

            }

        }else if($bookExists===false)
        {
            if(key_exists('addButton2', $_GET)==true)
            {
                //insert book
                $insertData="insert into tblorder values('The Good Game',1, 1, '2023-09-02',530);";
                

                //run the query 
                if($con->query($insertData)===true)
                {
                    //echo"added to cart";
                    
                }else
                {
                    $con->error;
                }

                
            }
            
            //add to cart history
            //add to orderline

            //write to order line table and history
                    //$insertData="insert into orderline values(".$row['orderName'].",".$row['orderUnits'].",". $row['bookId'].",". $row['orderdate'].",".$row['price'].");";
                    
                    if(key_exists('orderline2', $_GET)==true)
                    {
                        
                    }
        }
        //add to cart, by writing in orders
        //at the bottom of cart add button to clear the whole cart (delete table query)
        
            


        if(key_exists('cartButton', $_GET)==true)
    {
            //if($_GET['addButton']=='cartInsert')
            {
                //insert into orders table
            }
    }


        echo"
        <tr>
            <td><img src='Images\past_chronicles.png' height='100' width='auto'></td>
            <td><p> item name</p></td>
            <td><button id='myButton2'>View Price</button></td>
            <td><a href='store.php?addButton3=cartInsert' ><button> Add to cart</button></a>
            <a href='cart.php' ><button> View cart</button></a></td>
        </tr>
  
        

        <div id='myPopup2' class='popup'  width ='400' height='90'>
            <div class='popup-content'  width ='400' height='90'>
                
                <p>The price is R 1050</p>
                <button id='closePopup2'>Close</button>
            </div>
            
                <script>
                    myButton2.addEventListener('click', function () 
                    {
                        myPopup2.classList.add('show');
                    });

                    closePopup2.addEventListener('click', function () 
                    {
                        myPopup2.classList.remove('show');
                    });

                    window.addEventListener('click', function (event) 
                    {
                        if (event.target == myPopup2) 
                        {
                            myPopup2.classList.remove('show');
                        }
                    });
                </script>    
        </div>

        >";

           //check if exists, if does not, add, if it does update units
           $bookExists=false;
           if(key_exists('addButton3', $_GET)==true)
           {
           
           //compare form data with daatabase data
                   //the query
                   $searchQuery="select orderName from tblorder where orderName='Past Chronicles'";
                   
                   //result from the query
                   $result=$con->query($searchQuery);
                   
                   //looping on array returned by result
                   while($row=$result->fetch_assoc())
                   {
                       $someword=' thando booi';
                       if($row['orderName']==='Past Chronicles')
                       {
                           
                           $bookExists=true;
                           
                           break;
                       }
                   }
           
           }
           if($bookExists===true)
           {
               //update book units
               if(key_exists('addButton3', $_GET)==true)
               {
                   $updateQuery='update tblorder set orderUnits=orderUnits+ '. 1 ." WHERE orderName='Past Chronicles'";
                   //$con->query($updateQuery);
                   //run the query 
                   if($con->query($updateQuery)===true)
                   {
                       //echo"added to cart";
                       
                   }else
                   {
                       $con->error;
                   }
   
               }
   
           }else if($bookExists===false)
           {
               if(key_exists('addButton3', $_GET)==true)
               {
                   //insert book
                   $insertData="insert into tblorder values('Past Chronicles',1, 1, '2023-09-02',1050);";
                   
   
                   //run the query 
                   if($con->query($insertData)===true)
                   {
                       //echo"added to cart";
                       
                   }else
                   {
                       $con->error;
                   }
   
                   
               }
               
               //add to cart history
               //add to orderline
   
               //write to order line table and history
                       //$insertData="insert into orderline values(".$row['orderName'].",".$row['orderUnits'].",". $row['bookId'].",". $row['orderdate'].",".$row['price'].");";
                       
                       if(key_exists('orderline2', $_GET)==true)
                       {
                           
                       }
           }
           //add to cart, by writing in orders
           //at the bottom of cart add button to clear the whole cart (delete table query)
           
               
   
   
           if(key_exists('cartButton', $_GET)==true)
       {
               //if($_GET['addButton']=='cartInsert')
               {
                   //insert into orders table
               }
       }

        
        echo"
        <tr>
            <td><img src='Images\Tree_lab.png' height='100' width='auto'></td>
            <td><p> item name</p></td>
            <td><button id='myButton3'>View Price</button></td>
            <td><a href='store.php?addButton4=cartInsert' ><button> Add to cart</button></a>
            <a href='cart.php' ><button> View cart</button></a></td>

        </tr>
    
        

        <div id='myPopup3' class='popup'  width ='400' height='90'>
            <div class='popup-content'  width ='400' height='90'>
                <p>The price is R 740</p>
                <button id='closePopup3'>Close</button>

            </div>
            
                <script>
                    myButton3.addEventListener('click', function () 
                    {
                        myPopup3.classList.add('show');
                    });

                    closePopup3.addEventListener('click', function () 
                    {
                        myPopup3.classList.remove('show');
                    });

                    window.addEventListener('click', function (event) 
                    {
                        if (event.target == myPopup3) 
                        {
                            myPopup3.classList.remove('show');
                        }
                    });
                </script>    
        </div>

       
        <br>";
        
           //check if exists, if does not, add, if it does update units
           $bookExists=false;
           if(key_exists('addButton4', $_GET)==true)
           {
           
           //compare form data with daatabase data
                   //the query
                   $searchQuery="select orderName from tblorder where orderName='Tree Lab'";
                   
                   //result from the query
                   $result=$con->query($searchQuery);
                   
                   //looping on array returned by result
                   while($row=$result->fetch_assoc())
                   {
                       $someword=' thando booi';
                       if($row['orderName']==='Tree Lab')
                       {
                           
                           $bookExists=true;
                           
                           break;
                       }
                   }
           
           }
           if($bookExists===true)
           {
               //update book units
               if(key_exists('addButton4', $_GET)==true)
               {
                   $updateQuery='update tblorder set orderUnits=orderUnits+ '. 1 ." WHERE orderName='Tree Lab'";
                   //$con->query($updateQuery);
                   //run the query 
                   if($con->query($updateQuery)===true)
                   {
                       //echo"added to cart";
                       
                   }else
                   {
                       $con->error;
                   }
   
               }
   
           }else if($bookExists===false)
           {
               if(key_exists('addButton4', $_GET)==true)
               {
                   //insert book
                   $insertData="insert into tblorder values('Tree Lab',1, 1, '2023-09-02',740);";
                   
   
                   //run the query 
                   if($con->query($insertData)===true)
                   {
                       //echo"added to cart";
                       
                   }else
                   {
                       $con->error;
                   }
   
                   
               }
               
               //add to cart history
               //add to orderline
   
               //write to order line table and history
                       //$insertData="insert into orderline values(".$row['orderName'].",".$row['orderUnits'].",". $row['bookId'].",". $row['orderdate'].",".$row['price'].");";
                       
                       if(key_exists('orderline2', $_GET)==true)
                       {
                           
                       }
           }
           //add to cart, by writing in orders
           //at the bottom of cart add button to clear the whole cart (delete table query)
           
               
   
   
           if(key_exists('cartButton', $_GET)==true)
       {
               //if($_GET['addButton']=='cartInsert')
               {
                   //insert into orders table
               }
       }

        echo"

        <tr>
            <td><img src='Images\Vintage_collectors.png' height='100' width='auto'></td>
            <td><p> item name</p></td>
            <td><button id='myButton4'>View Price</button></td>
            <td><a href='store.php?addButton5=cartInsert' ><button> Add to cart</button></a>
            <a href='cart.php' ><button> View cart</button></a></td>
       </tr>
       </table> <!--product table-->

        

        
        <div id='myPopup4' class='popup'  width ='400' height='90'>
            <div class='popup-content'  width ='400' height='90'>
                <p>The price is R 900</p>
                <button id='closePopup4'>Close</button>

            </div>
            
                <script>
                    myButton4.addEventListener('click', function () 
                    {
                        myPopup4.classList.add('show');
                    });

                    closePopup4.addEventListener('click', function () 
                    {
                        myPopup4.classList.remove('show');
                    });

                    window.addEventListener('click', function (event) 
                    {
                        if (event.target == myPopup4) 
                        {
                            myPopup4.classList.remove('show');
                        }
                    });
                </script>
        </div>";

   //check if exists, if does not, add, if it does update units
   $bookExists=false;
   if(key_exists('addButton5', $_GET)==true)
   {
   
   //compare form data with daatabase data
           //the query
           $searchQuery="select orderName from tblorder where orderName='Vintage Collectors'";
           
           //result from the query
           $result=$con->query($searchQuery);
           
           //looping on array returned by result
           while($row=$result->fetch_assoc())
           {
               $someword=' thando booi';
               if($row['orderName']==='Vintage Collectors')
               {
                   
                   $bookExists=true;
                   
                   break;
               }
           }
   
   }
   if($bookExists===true)
   {
       //update book units
       if(key_exists('addButton5', $_GET)==true)
       {
           $updateQuery='update tblorder set orderUnits=orderUnits+ '. 1 ." WHERE orderName='Vintage Collectors'";
           //$con->query($updateQuery);
           //run the query 
           if($con->query($updateQuery)===true)
           {
               //echo"added to cart";
               
           }else
           {
               $con->error;
           }

       }

   }else if($bookExists===false)
   {
       if(key_exists('addButton5', $_GET)==true)
       {
           //insert book
           $insertData="insert into tblorder values('Vintage Collectors',1, 1, '2023-09-02',900);";
           

           //run the query 
           if($con->query($insertData)===true)
           {
               //echo"added to cart";
               
           }else
           {
               $con->error;
           }

           
       }
       
       //add to cart history
       //add to orderline

       //write to order line table and history
               //$insertData="insert into orderline values(".$row['orderName'].",".$row['orderUnits'].",". $row['bookId'].",". $row['orderdate'].",".$row['price'].");";
               
               if(key_exists('orderline2', $_GET)==true)
               {
                   
               }
   }
   //add to cart, by writing in orders
   //at the bottom of cart add button to clear the whole cart (delete table query)
   
       


   if(key_exists('cartButton', $_GET)==true)
{
       //if($_GET['addButton']=='cartInsert')
       {
           //insert into orders table
       }
}

            }

            public function styleShop()
            {
                echo 
                "
                <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,a
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: green;
                }

                #c
                {
                    background-color:rgb(238, 242, 246) ;
                    color: aquamarine;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 0%;
                    margin-left: 6%;
                }

                h,p,#dashLinks,a
                {
                    margin-left: 16%;
                }

                #allUsersVerifiedMsg
                {
                    color: grey;
                    margin-left: 20%;
                    font-style: italic;
                    font-size: 10px;
                }

            </style>
            <style>

                table 
                {
                    width:50%;
                    margin-left: 15%;
                    font-family: 'Lucida Sans';
                }

                td 
                {
                    background-color: ghostwhite;
                }

                th,td 
                {
                    font-weight: bold;
                    /*border: 1px solid black;*/
                    padding: 10px;
                    text-align: center;
                }

                td 
                {
                    font-weight: lighter;
                }

            </style>
    		<style>
                    .popup 
                    {
                        position: fixed;
                        z-index: 1;
                        left: 0;
                        top: 0;
                        width: 100%;
                        height: 100%;
                        overflow: auto;
                        background-color: rgba(0, 0, 0, 0.4);
                        display: none;
                    }

                    .popup-content 
                    {
                        background-color: white;
                        margin: 10% auto;
                        padding: 20px;
                        border: 1px solid #888888;
                        width: 60%;
                        font-weight: bolder;                        
                    }

                    .popup-content button 
                    {
                        display: block;
                        margin: 0 auto;
                        border-radius: 10%;
                    }

                    .show 
                    {
                        display: block;   
                    }

                    h1 
                    {
                        color: green;
                    }

            </style>
            <style>
				
				a
				{
					color: rgb(255, 174, 0);
					font-family: 'Lucida Sans';
				}

				#adminForm
				{
					margin-left:10%;
					font-family: 'Lucida Sans';
				}
				
                

				Button
				{
					margin-left: 15%;
					font-family: 'Lucida Sans';
					
					
                    border-color: rgb(225, 218, 218);
                    border-width: 0px;

                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                    
				}

                #myCartButton, #myCartButton1, #myCartButton2, #myCartButton3, #myCartButton4
                {
                    margin-left: 15%;
					font-family: 'Lucida Sans';
					background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

				h2
				{
					
					color: rgb(17, 64, 121);
				}

				p
				{
                    margin-left: 12%;
					color: rgb(255, 174, 0);
				}

                img
                {
                    margin-left: 10%;
                }

                /*#navbar
                {
                    width:80%;
                    height:20%;
                    margin-left:10%;
                    background-color:blue;
                    border-radius: 8%;
                }*/

			</style>
                ";
            }

            //echo "<script>alert('hi there')</script>";
			//echo "<a href='#' onclick='alert(\"hi there\");'>shelf 1</a>";
			//echo "<button type='submit' onclick=alert('hi there') name='submit'>Add To Cart</button>";
			//window.alert('xxd');
        }
        
        $shop= new store();
        $shop->showHeader();
        $shop->checkBookExistence();
        $shop->createUsersTable();
        //$shop->loadBookStoreTables();
        $shop->showBooksTable();
        $shop->showBooks();
        $shop->styleShop();
    ?>
          
		    <!-- PHP code to establish connection with the localserver -->  
            <!-- HTML code to display data in tabular format -->
            <!-- CSS FOR STYLING THE PAGE -->    
		<!--add to orders table-->
     
    </body>
</html>