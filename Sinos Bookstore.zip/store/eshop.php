<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
       <?php 
            class loginPage
            {
               
                
                 
            }

            
       ?>
        <h>ESHOP</h>
        <br>
        <br>
        <div id= loginLinks>
                
        </div>
        <br>

       
            <p>Hi ther welcome to our shop, we are an ecommerce store that specializes in selling both new and used books</p>
            <p>Our Goals are as follows:</p>
            <p>Help people easily get books</p>
            <p>Offer people a variety of book genres from different author all over the world</p>
            <p>cater for people who can afford both new and used books</p>
            
            <br>
           
            <a href=store.php><button id="addCar" >Eshop button</button></a>
            
      

        
            <?php 

               
                
            ?>
            
            <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,#loginLinks
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                #Name, #Password
                {
                    background-color:rgb(238, 242, 246) ;
                    color: aquamarine;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 10%;
                    margin-left: 36%;
                }

                h,p,button, #loginLinks
                {
                    margin-left: 16%;
                }

                button
                {
                    margin-left: 40%;
                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

                

            </style>
 
                
    </body>
</html>