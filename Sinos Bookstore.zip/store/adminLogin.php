<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
       
        <h>Admin Login</h>
        
        <br>
        <br>
        
        

        <form method="post">
            <p>Email: </p>
            <input id="Email" type="text" name="adminEmail">
            <br>
            <br>

            <p>Password: </p>
            <input id="password" type="text" name="adminPassword">
            <br>
            <br>

            <button id="addCar" >Login</button>
        </form>
        <br>
       

        
            <?php 

                //check the admin email
                if(key_exists("adminEmail",$_POST))
                {
                    $admiinEmail=$_POST["adminEmail"];

                    if($admiinEmail=="user@admin.com")
                    {
                        header("Location:../adminDash.php");
                    }
                    else
                    {
                        echo'<p id="resultant">', 'Please check the email','</p>';
                        
                    }

                    //check the password
                }

                echo '<a href=userLogin.php>BACK TO USER LOGIN     &nbsp;</a>';

            ?>
            <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,a
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                #Email, #password
                {
                    background-color:rgb(238, 242, 246) ;
                    color: black;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 10%;
                    margin-left: 36%;
                }

                h,p,a
                {
                    margin-left: 36%;
                }

                button
                {
                    margin-left: 36%;
                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

            </style>
 
                
    </body>
</html>