<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
        
        <form method="post">
            <h>Cart <a href=store.php>Continue to store</a></h>
            <p></p>
           <!-- <button name="v">click me</button>-->
        </form>
        <br>

        <?php 

            class cart
            {
                
                public function determineThumbnail($orderName)
                {
                    $imageName='';
                    switch($orderName)
                    {
                        case 'Physio Touch':
                            $imageName='Images\physio.png';
                            break;
                        case 'The Good Game':
                                $imageName='Images\good_game.png';
                                break;
                        case 'Past Chronicles':
                                $imageName='Images\past_chronicles.png';
                                break;
                        case 'Tree Lab':
                                $imageName='Images\tree_lab.png';
                                break;
                        case 'Vintage Collectors':
                                $imageName='Images\Vintage_collectors.png';
                                break;
                                    
                    }
                    return $imageName;
                }

                public function showCart()
                {
                    cart::cancelOrder();
                    include('DBConn.php');
                    $name;
                    $userName;
                    $studentNumber;
                    $password;
                
                    if($_SERVER["REQUEST_METHOD"]=="POST")
                    {
                        //get form data
                    }
                    
                    //if(key_exists("verify2", $_POST)==true)
                    {
                    //collect from a pendingUsers table

                        $result=$con->query("select * from tblorder");
                        /*echo '<table  ><tr>'.
                        '<th>Book</th>'.
                        '<th>Name</th>'.
                        '<th>Price</th>'.
                        '<th>Quantity</th>'.
                         '</tr></table>';*/
                        //fetch rows from pendingUsers and insert into tblUsers
                        while($row=$result->fetch_assoc())
                        {
                            //use orderName
                            //function returning image string if order is of certain value
                            
                            echo '<table  ><tr>';
                           
                            echo '<div id="cartTable">';
                            echo "<td><img id='thumbnail' src=",cart::determineThumbnail($row['orderName'])," height='80' width='auto'></td>";
                            echo '<td><p>',$row['orderName'].'</p></td>';
                            echo '<td><p>'."R ". $row['price'].'</p></td>';
                            echo '<td><p>'.$row['orderUnits'],' units','</p></td>';
                            
                            
                            // echo "<p>New Order Units <input id='unitsInputs' type='text' name='inText' ><br> </p>";
                            
                            echo "<td><a href='cart.php?cancelOrder=".$row['orderName']."'>"."<button>cancel order</button></a></td>";
                            echo '</div>';
                            echo '</tr></table>';
                           // cart::cancelOrder($row['orderName']);
                            //echo "<button id='addUnit'>",'update Units</button>';
                            //buttons should have order names as ids
                            //id is used to query a delete from orders table and reload page.
                            //click order line to fetch again without displaying but inserting each record into order line table (clear table on clicking finish) and history table
                            
                           // echo "<a href='cart.php? orderline2=add'><button >",'to orderline</button></a>','<br>','<br>';
                            
                            
                            

                            //fetch a cartUpdatedItem page
                            echo 
                            "
                                <script>
                                cancelOrder.addEventListener('click', function()
                                {
                                    showText();
                                });

                                function showText()
                                {
                                    var element=document.createElement('p');
                                    element.innerText='stringer';
                                    document.body.appendChild(element);
                                }
                                </script>";
                            $orderName=$row['orderName'];
                            $orderUnits=$row['orderUnits'];
                            //$password=$row['hashcode'];
                              
                            //update instead
                            //verify them, insert them into users under if.	//insert under condition
                            /*$insertData="insert into tblUser values
                            (userId,'$name', '$userName', '$password');";
                            
                            if($con->query($insertData)===true)
                            {

                            }else
                            {
                                $con->error;
                            }*/
                        }
                        
                        //clear pending users
                        //$con->query("delete from pendingusers;");
                        
                        //ESTABLISHED
                        $haveUnverifiedUsers=false;
                        if($haveUnverifiedUsers==false)
                        {
                            
                        }else
                        {
                            echo '<p id="allUsersVerifiedMsg">This should be a table of users</p>';
                        }
                        //header("Location:../adminDash.php");
                    }
                }  
                

                public function cancelOrder()
                {   
                    include('DBConn.php');
                   // $_GET['cancelNow']='undefined';

                        //check values
                        $unitsAvailable=false;
                        
                        if(key_exists("cancelOrder",$_GET)==true)
                        {
                        //compare form data with daatabase data
                                //the query
                                $searchQuery="select orderUnits from tblorder where orderName=". "'".$_GET['cancelOrder']. "'";
                                
                                //result from the query
                                $result=$con->query($searchQuery);
                                
                                //looping on array returned by result
                                while($row=$result->fetch_assoc())
                                {
                                    $someword=' thando booi';
                                    if($row['orderUnits']!==0)
                                    {
                                        
                                        $unitsAvailable=true;
                                        
                                        break;
                                    }else
                                    {
                                        $unitsAvailable=false;
                                    }
                                }
                        
                        

                        //take action
                        //if($unitsAvailable==false )
                        {
                            $updateQuery='delete from tblorder '." WHERE orderName=". "'".$_GET['cancelOrder']. "'";
                            $con->query($updateQuery);

                        }

                            
                        }
                        
                    
                    /*else if(key_exists("cancelNow",$_GET))
                    {
                        $deleteBook="delete from tblbooks where title='".$_GET['deleteBookField']."';";
                        $con->query($deleteBook);
                        //delete key because it delete on refresh
                        // $_POST['deleteBookField']=null;
                    }*/
                    
                    //
                       
                }
                
                public function showCheckout()
                {
                    echo"<br><h>Checkout</h>";
                    cart::showRefNumber();

                   
                }

                public function returnToLogin()
                {

                }

                public function showRefNumber()
                {
                    //a random number (javaScript or PHP) could come in handy here
                    echo"<p>Order Number:783439</p>";
                    echo"<p>Session ID:75839407fv9</p>";

                }
                
                public function decreaseUnits($rawUnits)
                {
                    $newUnits=$rawUnits-($rawUnits*0.3);
                    if($newUnits<0)
                    {
                        $newUnits=0;
                    }
                    return $newUnits;
                }

                public function writeToOrderLine()
                {
                    //view orderline, updating all unit (-1) 
                   
                    if(key_exists("orderline",$_GET)==true)
                    {
                        echo "<br><p>Order Line</p>"; 
                        echo"         
                        <section>
                        <table>
                            <tr>
                                <th>OrderName</th>
                                <th>Quantity</th>
                                
                                <th>PriceY</th>
                            </tr>

                        ";    //PHP CODE TO FETCH DATA FROM ROWS -->

                        
            
                            include('DBConn.php');

                            
                            

                            //read from order
                        
                        {
                        //collect from a pendingUsers table
                            //read order on the orders table
                            $result=$con->query("select * from tblorder");
    
                            //fetch rows from pendingUsers and insert into tblUsers
                            while($row=$result->fetch_assoc())
                            {
                                //use orderName
                                //function returning image string if order is of certain value
                                //display
                                //echo $row['orderName'];
                                
                                //echo $row['orderName'],'XX ',$row['price'],'  - ',$row['orderUnits'];
                                //echo "<p>New Order Units <input id='unitsInputs' type='text' name='inText' ><br> </p>";
                                
                                $name=$row['orderName'];
                                $units=$row['orderUnits'];
                                $id=0;
                                $date='0000-00-00';
                                $price=$row['price'];
                                //write into orderline table
                                //$con->query("insert into orderline values(".'a'.','.'a'.','. 0 .','. '0000-00-00' .','.'a'.");");
                                //$con->query("insert into orderline values('b',0, 0 ,'0000-00-00' ,1);");
                                
                                //Query that  inserts into the order line then modifies or decreases units or qunitity ordered
                                $request="insert into orderline values("."'".$name ."'"."," . cart::decreaseUnits($units) .','. 0 .','. '0' .','. $price .');';
                                $con->query($request);
                                
                                //insert into history
                                cart::writeHistoryTable($name, $units, $price);
                                
                                //$con->query("insert into orderline values(".$row['orderName'].','.$row['orderUnits'].','. 0 .','. '0000-00-00' .','.$row['price']).";)";
                                //buttons should have order names as ids
                                //id is used to query a delete from orders table and reload page.
                                //click order line to fetch again without displaying but inserting each record into order line table (clear table on clicking finish) and history table
                                
                               // echo "<a href='cart.php? orderline2=add'><button >",'to orderline</button></a>','<br>','<br>';
                                
                                
                                
    
                                //fetch a cartUpdatedItem page
                                echo 
                                "
                                    <script>
                                    cancelOrder.addEventListener('click', function()
                                    {
                                        showText();
                                    });
    
                                    function showText()
                                    {
                                        var element=document.createElement('p');
                                        element.innerText='stringer';
                                        document.body.appendChild(element);
                                    }
                                    </script>";
                                $orderName=$row['orderName'];
                                $orderUnits=$row['orderUnits'];
                                //$password=$row['hashcode'];
                                  
                                //update instead
                                //verify them, insert them into users under if.	//insert under condition
                                /*$insertData="insert into tblUser values
                                (userId,'$name', '$userName', '$password');";
                                
                                if($con->query($insertData)===true)
                                {
    
                                }else
                                {
                                    $con->error;
                                }*/
                            }
                            
                            //clear pending users
                            //$con->query("delete from pendingusers;");
                            
                            //ESTABLISHED
                            $haveUnverifiedUsers=false;
                            if($haveUnverifiedUsers==false)
                            {
                                
                            }else
                            {
                                echo '<p id="allUsersVerifiedMsg">This should be a table of users</p>';
                            }
                            //header("Location:../adminDash.php");
                            }




                            //$result=$con->query("select * from orderline");
                            // SQL query to select data from database
                            //bookId,title,available_copies,price

                            //read from the recently inserted into orderline table 
                            $sql2=" select * from orderline ;";
                            //result from the query
                            $result=$con->query($sql2);
                            //$mysqli->close();
                            $result=$con->query($sql2);

                            // LOOP TILL END OF DATA
                            while($rows=$result->fetch_assoc())
                            {
                                

                            echo"
                                <tr>
                                    <!-- FETCHING DATA FROM EACH
                                        ROW OF EVERY COLUMN -->
                                        <td>",  $rows['orderName'],"</td>
                                            <td>",  $rows['orderUnits'],"</td>
                                            
                                            <td>", "R" ,$rows['price'],"</td>
                                </tr>
                                ";
                                
                            }
                        

                                        
                            echo        "</table>
                                </section>
                                <br>
                                <br>";
                    }

                }

                public function emptyTheCartArray()
                {

                }

                public function writeHistoryTable($name, $units, $price)
                {
                    include('DBConn.php');

                    $historyrequest="insert into historyReport values("."'".$name ."'"."," . cart::decreaseUnits($units) .','. 0 .','. '0' .','. $price .');';                                
                    $con->query($historyrequest);
                }
                
                public function displayHistory()
                {
                    if(key_exists("history",$_GET)==true)
                    {
                                //echo " <p>this will be the history</p>";

                                //show data from the history table
                                //this means all checked out items should reflect 
                                //orders table should be updated to have totals
                            

                            //view orderline, updating all unit (-1)
                            
                            echo"         
                            <section>
                            <table>
                                <tr>
                                    <th>OrderName</th>
                                    
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </tr>
        
                            ";    //PHP CODE TO FETCH DATA FROM ROWS -->
        
                            
                
                                include('DBConn.php');
        
                                // SQL query to select data from database
                                //bookId,title,available_copies,price
                                $sql2=" select * from historyReport ;";
                                //result from the query
                                $result=$con->query($sql2);
                                //$mysqli->close();
        
                                $result=$con->query($sql2);
                                
                                // LOOP TILL END OF DATA
                                while($rows=$result->fetch_assoc())
                                {
                                    
        
                                echo"
                                    <tr>
                                        <!-- FETCHING DATA FROM EACH
                                            ROW OF EVERY COLUMN -->
                                                <td>",  $rows['orderName'],"</td>
                                                
                                                <td>",  $rows['orderUnits'],"</td>
                                                <td>", "R" ,$rows['price'],"</td>
                                    </tr>
                                    ";
                                    
                                }
                            
        
                                            
                                echo        "</table>
                                    </section>
                                    ";
                    }

                    include('DBConn.php');
                    $total;
                    //query to 
                    $getTotalSpent='select sum(subtotal) from historyR';
                    $result=$con->query($getTotalSpent);
                    while($rows=$result->fetch_assoc())
                    {
                        $total=$rows['sum(subtotal)'];
                    }
                    
                    echo "<p>Total of all purchases is: R ".$total.".00</p>";

                 }

                 
            } 
                $shoppingCart=new cart();
                $shoppingCart->showCart();
               
                
                echo "<br><br><a href='cart.php?orderline=added'><button>Add to orderline</button></a><br><br>";
               // $_GET['cancelNow']='undefined';
               // if($_GET['cancelNow']!=='undefined')
                
                
                $shoppingCart->showCheckout();
                $shoppingCart->writeToOrderLine();
                echo "<br><a href='cart.php?history=show'><button>Show purchase history</button></a>";
                
                $shoppingCart->displayHistory();
                
                echo"<br><br><a href='userLogin.php?finish=clearOrderline'><button>Checkout</button></a>";


            ?>

            <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,a
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                #unitsInputs, #addUnit, #cancelOrder
                {
                    background-color:rgb(238, 242, 246) ;
                    color: aquamarine;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 0%;
                    margin-left: 5%;
                }

                button,#addUnit, #cancelOrder
                {
                    margin-left: 15%;
					font-family: 'Lucida Sans';
					background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

                img, #thumbnail
                {
                    margin-left: 15%;
                }

                #unitsInputs, h,p,button,#dashLinks,a
                {
                    margin-left: 16%;
                }

                #allUsersVerifiedMsg
                {
                    color: grey;
                    margin-left: 20%;
                    font-style: italic;
                    font-size: 10px;
                    
                }

            </style>
            <style>
                
                

                table 
                {
                    margin-left: 15%;
                    font-family: 'Lucida Sans';
                    width: 50%;
                }

                td 
                {
                    background-color: ghostwhite;
                    width: 15%;
                }

                #cartTable
                {
                    background-color: white;
                    color: white;
                    
                }

                th,td 
                {
                    font-weight: bold;
                    /*border: 1px solid black;*/
                    padding: 10px;
                    text-align: center;
                }

                td 
                {
                    font-weight: lighter;
                }

            </style>
 
    </body>
</html>