<!DOCTYPE html >
<html lang="en" >
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
       <?php 
            class loginPage
            {
               
                public function clearOrderLine()
                 {
                    include('DBConn.php');
 
                    $clearOrderLine=" delete from orderline ;";
                    //result from the query
                    $con->query($clearOrderLine);
                    //echo "<p>orderline cleared</p>";
                 }

                 
            }

            $sampleLoginPage=new loginPage();
            $sampleLoginPage->clearOrderLine();
       ?>
        <h>Web Name</h>
        <br>
        <br>
        <div id= loginLinks>
            <a href=userRegistration.php>Register as user     &nbsp;</a>
            <a href=adminLogin.php>Login as admin     &nbsp;</a>    
        </div>
        <br>

        <form method="post">
            <p>Username: </p>
            <input id="Name" type="text" name="Username">
            <br>
            <br>

            <p>Password: </p>
            <input id="Password" type="text" name="UserPassword">
            <br>
            <br>

            <button id="Login" >Login</button>
        </form>

        
            <?php 

                if(key_exists("UserPassword",$_POST))
                {
                    //check the username

                    //check the password
                    $password=$_POST["UserPassword"];

                    if($password=="password123")
                    {
                        header("Location:../eshop.php");
                    }
                    else
                    {
                        echo'<p id="resultant">', 'Please check the password','</p>';
                        
                    }
                }

                class userLoginPage
                {
                    public function loadBookStoreTables()
                    {
                        //load bookstore
                        include('DBConn.php');
                        
                        $exists =mysqli_connect_error(/*$con, "select 1 from tblUser"*/);
                            /*$exist2=mysql_query("select 1 from tblUser limit 1");
                            if(mysql_query("describe tblUser"))
                            {
                                
                            }*/
                            
                            if($exists!==false)
                            {
                                $delete= mysqli_query($con, "drop table tblUser");
                                //echo "table dropped";
                                echo '<br>';
                                $create_tblUser= "create table if not exists tblUser(userId int auto_increment primary key,
                                                  name_ varchar(20), 
                                                  email varchar(50), 
                                                  hashcode varchar(100), 
                                                  seller int default 0);";
                                
                                $delete= mysqli_query($con, "drop table tblAdmin");
                                //echo "table dropped";
                                $create_tblAdmin= "create table if not exists tblAdmin(adminId int auto_increment primary key, 
                                                   name_ varchar(20));";
                                
                                //$delete= mysqli_query($con, "drop table tblorder");
            
                                //echo "table dropped";
                                $create_tblBooks= "create table if not exists tblBooks(bookId int auto_increment primary key, 
                                                   title varchar(50), 
                                                   available_copies int, price int); ";
                                
                                $delete= mysqli_query($con, "drop table tblBooks");
                                //echo "table dropped";															
                               // $create_tblorder= "create table if not exists tblorder(orderName varchar(50) , orderUnits int, 
                                  //                  bookId int ,orderdate date);"; 
                                
                                if($con->query($create_tblUser)=== true)
                                {
                                    //echo "Table recreated successfully";
                                }else
                                {
                                    echo "Error creating table".$con->error;
                                }
                                
                                if($con->query($create_tblAdmin)=== true)
                                {
                                    //echo "Table recreated successfully";
                                }else
                                {
                                    echo "Error creating table".$con->error;
                                }
                                
                                if($con->query($create_tblBooks)=== true)
                                {
                                    //echo "Table recreated successfully";
                                }else
                                {
                                    echo "Error creating table".$con->error;
                                }
                                
                                //if($con->query($create_tblorder)=== true)
                                {
                                    //echo "Table recreated successfully";
                                }//else
                                {
                                   // echo "Error creating table".$con->error;
                                }
            
                            $serverName="localhost";
                            $userName="root";
                            $password="";
                            $dbName="bookstore";
            
                                mysqli_query($con, "set global local_infile=1");
                                mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblUser.txt' into table tblUser fields
                                terminated by ',' lines terminated by '\n';") 
                                 or  die('Error loading data file.<br>'.mysqli_error($con));
                                 
                                mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblAdmin.txt' into table tblAdmin fields
                                terminated by ',' lines terminated by '\n';") 
                                 or  die('Error loading data file.<br>'.mysqli_error($con));
                                
                                mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblBooks.txt' into table tblBooks fields
                                terminated by ',' lines terminated by '\n';") 
                                 or  die('Error loading data file.<br>'.mysqli_error($con));
                                
                                /*mysqli_query($con, "load data local infile 'D:/school/WED/WED Part 2/tblorder.txt' into table tblorder fields
                                terminated by ',' lines terminated by '\n';") 
                                 or  die('Error loading data file.<br>'.mysqli_error($con));*/
                            }else
                            {
                                echo("This table does not exist");
                            }
                            
                            //echo "THIS IS THE LOAD BOOKSTORE PAGE";
                    }

                    public function clearCart()
                    {
                        include('DBConn.php');
                        if(key_exists('finish',$_GET)===true)
                        {
                            $emptyCart='delete from tblorder;';
                            $con->query($emptyCart);
                        }
                    }
                }

                $usersLoginPage=new userLoginPage();
                $usersLoginPage->loadBookStoreTables();
                $usersLoginPage->clearCart();
            ?>
            
            <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,#loginLinks
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                #Name, #Password
                {
                    background-color:rgb(238, 242, 246) ;
                    color: black;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 10%;
                    margin-left: 36%;
                }

                h,p,button, #loginLinks
                {
                    margin-left: 36%;
                    
                }

                button
                {
                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

                

            </style>

            
 
                
    </body>
</html>