<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="stylingsheet.css" rel="stylesheet" type="text/css"/>

        
    </head>
    <body background="Images/background.png">
       <?php 
            class Dashboard
            {
                public function showDashboard()
                {
                    echo "<h>Admin Dashboard</h>
                        <br>
                        <br>
                        <div id= dashLinks>
                        <a href=adminLogin.php>Logout      &nbsp</a>
                        <a href=store.php>Continue to store</a>   
                        <a href=adminMessages.php>Chat</a>   

                        </div>
                        <br>
                        <br>";
                }

                public function showPendingUsers()
                {
                    include('DBConn.php');
                
                    $name;
                    $userName;
                    $studentNumber;
                    $password;
                    
                        if($_SERVER["REQUEST_METHOD"]=="POST")
                        {
                            //get form data
                        }
                        
                        if(key_exists("verify2", $_POST)==true)
                        {
                        //collect from a pendingUsers table
    
                            $result=$con->query("select name_,email, hashcode from pendingusers");
    
                            //fetch rows from pendingUsers and insert into tblUsers
                            while($row=$result->fetch_assoc())
                            {
                                //echo 'Name and surname: ',$row['name_'],' <br>',$row['email'],'<br>',$row['hashcode'],'<br>','<br>';					
                                $name=$row['name_'];
                                $userName=$row['email'];
                                $password=$row['hashcode'];
                                    
                                //verify them, insert them into users under if.	//insert under condition
                                $insertData="insert into tblUser values
                                (userId,'$name', '$userName', '$password');";
                                
                                if($con->query($insertData)===true)
                                {
    
                                }else
                                {
                                    $con->error;
                                }
                            }
                            
                            //clear pending users
                            $con->query("delete from pendingusers;");
                            
                            //ESTABLISHED
                            $haveUnverifiedUsers=false;
                            if($haveUnverifiedUsers==false)
                            {
                                
                            }else
                            {
                                echo '<p id="allUsersVerifiedMsg">This should be a table of users</p>';
                            }
                            header("Location:../adminDash.php");
                        }
                
                }

                public function manageUsers()
                {
                    include('DBConn.php');
                    echo "<h>Manage users</h>
                        <form method='post'>
                              <p>Verify users: </p>";    

                             
                              $result=$con->query("select name_,email, hashcode from pendingusers");
                              echo '<p id="allUsersVerifiedMsg">All users to verify</p>';
                              while($row=$result->fetch_assoc())
                              {
                                echo '<table><tr>';
                                echo 
                                '<tr>
                                   <th>Name</th>
                                   <th>Email</th>
                                   <th>hash password</th>
                                   
                                </tr>';
                                  echo '<td><p>',$row['name_'],'</p></td>';					
                                  echo '<td><p>'.$row['email'].'</p></td>';
                                  echo '<td><p>'.$row['hashcode'].'</p></td>';
                                echo '</tr></table><br>';
                                  
                                  $name=$row['name_'];
                                  $userName=$row['email'];
                                  $password=$row['hashcode'];
                              }

                    echo     "<button id='verifyButton' name='verify2'>Verify</button>
                              <br>
                              <br>
                        </form>";


                    echo "<form>
                            <p>delete user: </p>
                            <input id='deleteUserID' type='text' name='deleteUser'>
                            <br>
                            <br>
                            <button id='deleteButton' >Delete</button>
                            <br>
                            <br>
                        </form>
                
                        <br>
                        <br>";
                }

                public function determineThumbnail($number)
                {
                    $imageName='';

                    if(key_exists('icon', $_GET)==true)
                    {
                        switch($number)
                        {
                            case '1':
                                $imageName='Images\physio.png';
                                break;
                            case '2':
                                    $imageName='Images\good_game.png';
                                    break;
                            case '3':
                                    $imageName='Images\past_chronicles.png';
                                    break;
                            case '4':
                                    $imageName='Images\tree_lab.png';
                                    break;
                            case '5':
                                    $imageName='Images\Vintage_collectors.png';
                                    break;
                                        
                        }
                    }
                    

                    return $imageName;
                }

                public function manageBooks()
                {//before enabling more functionality, move functions to recreate tables to a link or page
                    Dashboard::addNewBook();
                    Dashboard::editBook();
                    Dashboard::deleteBook();
                    echo " <h>Manage books</h>
                           <br><p>ALL BOOKS IN STORE</p>",
                           "         
                           <section>
                           <table>
                               <tr>
                                   <th>bookId</th>
                                   <th>Book Title</th>
                                   <th>available_copies</th>
                                   <th>Price</th>
                               </tr>
       
                           ";    //PHP CODE TO FETCH DATA FROM ROWS -->
       
                            
               
                               include('DBConn.php');
       
                               // SQL query to select data from database
                               $sql2=" select * from tblbooks ;";
                               //result from the query
                               $result=$con->query($sql2);
                               //$mysqli->close();
       
                               $result=$con->query($sql2);
                               
                               // LOOP TILL END OF DATA
                               while($rows=$result->fetch_assoc())
                               {
                                   
       
                               echo"
                                   <tr>
                                       <!-- FETCHING DATA FROM EACH
                                           ROW OF EVERY COLUMN -->
                                              <td>",  $rows['bookId'],"</td>
                                               <td>",  $rows['title'],"</td>
                                               <td>",  $rows['available_copies'],"</td>
                                               <td>", "R" ,$rows['price'],"</td>
                                   </tr>
                                   ";
                                   
                               }
                                           
                               echo"</table>
                                   </section>
                                   <br>
                                   <br>", 
                        "
                            <p>Add book: </p>
                            
                        

                            <br>
                            <p>pick a thumbnail</p>
                            <div id='allIcons'>
                                <a href='adminDash.php?icon=1'><img src='Images\physio.png' height='120' width='auto'></a>
                                <a href='adminDash.php?icon=2'><img src='Images\good_game.png' height='120' width='auto'></a>
                                <a href='adminDash.php?icon=3'><img src='Images\past_chronicles.png' height='120' width='auto'></a>
                                <a href='adminDash.php?icon=4'><img src='Images\Tree_lab.png' height='120' width='auto'>
                                <a href='adminDash.php?icon=5'><img src='Images\Vintage_collectors.png' height='120' width='auto'></a>
                            </div><br>
                            <p>Thumbnail Picked </p>"
                            .
                            "<!--for this to work split the form, isolate to php and place in if-->";
                             
                            if(key_exists('icon', $_GET)==true)
                            {
                                echo "<img id='thumbnail' src=",Dashboard::determineThumbnail($_GET['icon'])," height='120' width='auto'><br>";

                            }
                            

                            echo"
                            <br>
                            <form method='POST' action='adminDash.php'>
                                <p>Book name:</p>
                                <input id='addBookID' type='text' name='newBook'><br><br>
                                <button id='addBookButton' >Add book</button>
                            </form>
                            <br>
                            <br>
                            
                        <form method='POST' action='adminDash.php'>
                            <p>Edit book: </p>
                            <p>Book Name: </p>
                            <input id='updateBook' type='text' name='updateBook'>
                            <br>
                            <p>New Name: </p>
                            <input id='updateBook2' type='text' name='updateBook2'>
                            <br>
                            <br>
                            <button id='updateBook3' >Edit book</button>
                            <br>
                            <br>
                        </form>

                        <form method='POST' action='adminDash.php'>
                            <p>Delete book: </p>
                            <input id='deleteBookId' type='text' name='deleteBookField'>
                            <br>
                            <br>
                            <button >Delete book</button>
                            
                            <br>
                            <br>
                        </form>

                        <br>";
                }

                public function addNewBook()
                {
                    include('DBConn.php');
                    if(key_exists('newBook',$_POST))
                    {
                        $addNewBook="insert into tblBooks values(bookId,"."'". $_POST['newBook']."'".", 10, 400);";
                        $con->query($addNewBook);
                    }

                    //perhaps add to store
                }
                
                public function verifyForm()
                {
                    if(key_exists("deleteUser",$_POST))
                    {
                        $userToDelete=$_POST["CarName"];
    
                        if(strlen($userToDelete)>0)
                        {
                            //start checking if user exists
                            //delete user
                        }
                        else
                        {
                            echo'<p id="resultant">', 'Please add a user','</p>';
                        }
                    }
                }

                public function editBook()
                {
                    include('DBConn.php');
                    if(key_exists('updateBook', $_POST)===true)
                    {
                        $updateBook="update tblbooks set title="."'". $_POST['updateBook2'] ."' "." WHERE title='". $_POST['updateBook']."';";
                        if($con->query($updateBook)===true)
                        {

                        }
                        else
                                {
                                    $con->error;
                                }
                    
                    }
                }

                public function deleteBook()
                {
                    include('DBConn.php');
                    if(key_exists("deleteBookField",$_POST))
                    {
                        $deleteBook="delete from tblbooks where title='".$_POST['deleteBookField']."';";
                        
                        
                        if($con->query($deleteBook)===true)
                        {

                        }
                        else
                                {
                                    $con->error;
                                }
                        //delete key because it delete on refresh
                       // $_POST['deleteBookField']=null;
                    }
                    
                    //
                       
                }
            }
        
        $dash=new Dashboard();
        $dash->showDashboard();
        $dash->manageUsers();
        $dash->showPendingUsers();
        $dash->manageBooks();
        $dash->verifyForm();
       // $dash->deleteBook();
        
        

       ?>
        
            <style>
                h
                {
                    font-family: 'Lucida Sans';
                    color: darkslateblue;
                }

                p,a
                {
                    font-family: verdana;
                    font-size: 12px;
                    color: orange;
                }

                input, #deleteUserID, #addBookID, #updateBookID, #deleteBookId
                {
                    background-color:rgb(238, 242, 246) ;
                    color: black;
                    border-color: gainsboro;
                    border-width: 0px;
                    border-radius: 0%;
                    margin-left: 16%;
                }

                #thumbnail
                {
                    margin-left: 15%;
                }

                #allIcons
                {
                    margin-left: 10%;
                }

                #dashLinks
                {
                    margin-left: 10%;    
                }

                a
                {
                    margin-left: 6%;
                }

                h,p,button
                {
                    margin-left: 16%;
                }

                button
                {
                    background-color: rgb(17, 64, 121);
					color: rgb(255, 255, 245);
                }

                #allUsersVerifiedMsg
                {
                    color: grey;
                    
                    font-style: italic;
                    font-size: 10px;
                }

            </style>
            <style>

                table 
                {
                    width: 80%;
                    margin-left: 15%;
                    font-family: 'Lucida Sans';
                }

                td 
                {
                    background-color: ghostwhite;
                }

                th,td 
                {
                    font-weight: bold;
                    /*border: 1px solid black;*/
                    padding: 10px;
                    text-align: center;
                }

                td 
                {
                    font-weight: lighter;
                }

            </style>

    </body>
</html>