<?php
				
                //the script must load text file in mySql then read from the resuling table

				$serverName="localhost";
				$userName="root";
				$password="";
				$dbName="bookstore";
				
				//$con=mysqli_init();
				
				//mysqli_options($con,MYSQLI_OPT_LOCAL_INFILE, true);
				//mysqli_real_connect($con,$serverName, $userName, $password, $dbName);
				//mysqli.local_infile=on;
				
				//mysql_connect($serverName, $userName, $password, false,128);
				//mysql_select_db($serverName);
				
				$con=mysqli_connect($serverName, $userName, $password, $dbName);
				
				if(!$con)
				{
					die("connection terminated by die". mysqLi_connect_error());
				}

				//$con->close();

?>