create database bookstore;
use bookstore;

create table if not exists tblUser(userId int auto_increment primary key,
                                                  name_ varchar(20), 
                                                  email varchar(50), 
                                                  hashcode varchar(100), 
                                                  seller int default 0);
                                                
create table if not exists tblAdmin(adminId int auto_increment primary key, 
                                                   name_ varchar(20));

create table adminLogin(adminId int, admin_name varchar (20), email varchar(50), hashcode varchar(200));
create table tbl_item(ItemID varchar(10), Description varchar(20), Cost_Price float, Quantity int, Sell_Price float );
create table if not exists tblBooks(bookId int auto_increment primary key, 
                                           title varchar(50), 
                                           available_copies int, price int);
                                           
create table orders(itemid int auto_increment primary key,item varchar (20),price float,qunatity int);
create table if not exists tblorder(orderName varchar(50) , orderUnits int, bookId int ,orderdate date); 
create table orderline(orderName varchar (50), orderUnits int, bookId int, orderdate varchar(20), price int);

create table historyReport(orderName varchar (50), orderUnits int, bookId int, orderdate varchar(20), price int);
create view historyR as select orderName, orderUnits booId, orderdate, price, price*orderUnits as subtotal from historyreport;
create table mbuyerssellers(message varchar(200));



