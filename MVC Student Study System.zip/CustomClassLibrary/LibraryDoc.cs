﻿using System.Text;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace CustomClassLibrary
{
    public class registrar
    {


        public registrar()
        {

        }

        public Boolean registerUser(String Name, String Surname, String Username, String Password, encrytor encrytorInstance, MySqlConnection connection)
        {
            connection.Open();

            string newUsername = Username;
            string newPassword = Password;
            
            Boolean readyToLogin = false;

            if (Name != null && Surname != null && Username != null && Password != null)
                if (Name != null)
                {
                    //Convert into password into hash
                    if (newPassword == null)
                    {
                        newPassword = "0";
                    }
                    string hashedPassword = encrytorInstance.ToSHA256(newPassword);

                    //find if the user exists first
                    //add if does not exits
                    //add if does not exit
                    MySqlCommand command = new MySqlCommand("INSERT INTO users(username, password_) VALUES (@username, @password_)", connection);
                    command.Parameters.AddWithValue("@username", newUsername);
                    command.Parameters.AddWithValue("@password_", hashedPassword);
                    command.ExecuteNonQuery();

                    //get id
                    string idquery = "select userid from users where username = '"
                       + newUsername + "'" + " and password_='" + hashedPassword + "';";
                    command = new MySqlCommand(idquery, connection);
                    //assign result
                    int idResult = (Int32)command.ExecuteScalar();

                    //get username
                    string namequery = "select username from users where username = '"
                       + newUsername + "'" + " and password_='" + hashedPassword + "';";
                    command = new MySqlCommand(namequery, connection);
                    //assign result
                    string nameResult = (string)command.ExecuteScalar();


                    //update users table to fill table field
                    command = new MySqlCommand("update  users set tableName=" + "'" + nameResult + idResult + "modules'" + " where userid= " + idResult + " ;", connection);
                    //command.Parameters.AddWithValue("@table", newUsername);
                    command.ExecuteNonQuery();

                    //create tables for the user-> modules and studyHours
                    //to make it better name the table with the user id as well
                    command = new MySqlCommand("create table if not exists " + nameResult + idResult +
                        "modules(moduleid int primary key auto_increment, moduleCode varchar(10), moduleName varchar(20)," +
                        " moduleCredits int, totalModulehours_per_week int\r\n,numberOfSemesterWeeks int, StudyDay varchar(20),requiredHours int, startDate varchar(20),hourStudied int default 0, sessiondate varchar(20) default '0');", connection);
                    command.ExecuteNonQuery();

                    connection.Close();


                    readyToLogin = true;

                }
            return readyToLogin;
        }

    }

    public class loginRunner
    {
        public string loginUser(String Username, String Password, encrytor encrytorInstance, MySqlConnection connection) 
        {
            string? viewName=null;
            if (Username != null && Password != null)
            {
                //grab data from IU
                //add data into the command
                string enteredUsername = Username;
                string enteredPassword = Password;

                string hashedPassword;
                //hash the entered password, execute if not null
                if (enteredPassword == null)
                {
                    enteredPassword = "0";
                }

                hashedPassword = encrytorInstance.ToSHA256(enteredPassword);

                string query = "select username from users where username = '"
                    + enteredUsername + "'" + " and password_='" + hashedPassword + "';";
                connection.Open();
                MySqlCommand command = new MySqlCommand(query, connection);
                string getUsername = (string)command.ExecuteScalar();


                //select password_ from users where password_ = "zenani";
                command.Parameters.AddWithValue("@username", Password);


                //judge the result
                //do something with it
                if (getUsername != null)
                {
                    if (getUsername.Equals(enteredUsername))
                    {
                        string tableName = "";
                        //get user table name
                        command = new MySqlCommand("select tableName from users where username='" + enteredUsername + "';", connection);
                        tableName = (string)command.ExecuteScalar();
                        //set the active table
                        command = new MySqlCommand("update activetable set tableName='" + tableName + "';", connection);
                        command.ExecuteNonQuery();

                        //return details of the user from that database


                        //prepare to run operations on relevent tables

                        //get username id
                        command = new MySqlCommand("select tableName from users where username='" + enteredUsername + "';", connection);
                        //command.ExecuteNonQuery();
                        //this.moduleTable = (String)command.ExecuteScalar();


                        viewName = "Index";
                    }
                    else
                    {
                        viewName = "loginApp";
                    }
                }
                else if (getUsername == null)
                {

                }
            }


            connection.Close();


            return viewName;
        }
    }

    public class moduleLogger
    {
        public FieldScanner FieldScannerInstance { get; set; }

        public moduleLogger() 
        {
            FieldScannerInstance = new FieldScanner();
        }

        public void addModule(String? moduleCode, String moduleName
            , String totalCredits, String HoursPerWeek, String weekdayStudy
            , String totalWeeks, String startDate, MySqlConnection connection) 
        {

            //this should run if all the fields are not null/empty
            if (moduleCode != null && moduleName != null && totalCredits != null && HoursPerWeek != null &&
                weekdayStudy != null && totalWeeks != null && startDate != null)
            {

                //code_ varchar(10), name_ varchar(20), num_credits int , week_hours int , num_weeks int , start_date date 
                connection.Open();
                //getting table name
                MySqlCommand command = new MySqlCommand("select tableName from activeTable;", connection);
                String tableName = (string)command.ExecuteScalar();


                //command to add data to the users module table
                command = new MySqlCommand("INSERT INTO " + tableName + "( moduleCode, moduleName, moduleCredits, totalModulehours_per_week, numberOfSemesterWeeks, StudyDay,requiredHours, startDate) " +
                    " VALUES ( @moduleCode, @moduleName, @moduleCredits, @totalModulehours_per_week, @numberOfSemesterWeeks, @StudyDay,@requiredHours , @startDate)", connection);
                //VALUES (@moduleCode, @moduleName, @moduleCredits, @totalModulehours_per_week, @numberOfSemesterWeeks, @startDate)

                command.Parameters.AddWithValue("@moduleCode", moduleCode);
                command.Parameters.AddWithValue("@moduleName", moduleName);
                command.Parameters.AddWithValue("@moduleCredits", Convert.ToInt32(totalCredits));
                command.Parameters.AddWithValue("@totalModulehours_per_week", Convert.ToInt32(HoursPerWeek));
                command.Parameters.AddWithValue("@numberOfSemesterWeeks", Convert.ToInt32(totalWeeks));
                command.Parameters.AddWithValue("@StudyDay", weekdayStudy);

                int reqHours=FieldScannerInstance.calculateSelfStudyHours(Convert.ToInt32(totalCredits), Convert.ToInt32(totalWeeks), Convert.ToInt32(HoursPerWeek));
                
                command.Parameters.AddWithValue("@requiredHours", Convert.ToInt32(reqHours));
                command.Parameters.AddWithValue("@startDate", startDate);

                command.ExecuteNonQuery();

                //use the statusbox id to target the status viewer
        
                //prep to display all studied modules
                command = new MySqlCommand("select count(*) from " + tableName + " ;", connection);
                command.ExecuteNonQuery();

                Int64 numRecords = (Int64)command.ExecuteScalar();
                //statusBox.Text = "module count was: " + numRecords;

                connection.Close();
            }

        }
    }


    public class sessionLogger
    {

        public void addSession(String studiedModule, String studiedHours
        , String dateStudied, MySqlConnection connection)
        {
            connection.Open();

            if (studiedModule != null && studiedHours != null && dateStudied != null)
            {
                MySqlCommand command = new MySqlCommand("select tableName from activeTable;", connection);
                String tableName = (string)command.ExecuteScalar();


                //check if module name exists first
                command = new MySqlCommand("update " + tableName + " set hourStudied= '" + studiedHours +
                    "' where moduleName='" + studiedModule + "';", connection);
                command.ExecuteNonQuery();

                //alter the session date field toString()
                command = new MySqlCommand("update " + tableName + " set sessiondate= '" + dateStudied +
                    "' where moduleName='" + studiedModule + "';", connection);
                command.ExecuteNonQuery();
            }

            connection.Close();
        }
    }

    public class modulesReader
    {
        //function gets the table of a logged in user
        public string getActiveTable(MySqlCommand command, MySqlConnection connection) 
        {
            string tableName = "select tableName from activeTable;";
            command = new MySqlCommand(tableName, connection);
            tableName = (string)command.ExecuteScalar();

            return tableName;
        }

        //function gets the number of modules from a user's module table
        public long getNumberOfRecords(MySqlCommand command, string table, MySqlConnection connection)
        {
            string queryNumberOfRecords = "select count(*)  from " + table + ";";
            command = new MySqlCommand(queryNumberOfRecords, connection);
            long numberOfRecords = (long)command.ExecuteScalar();

            return numberOfRecords;
        }

        //function runs different queries to get module data from a users table
        public typeToReturn runCommand<typeToReturn>(MySqlCommand command, string table, int startIDValue, MySqlConnection connection, int query) 
        {

            string selectedQuery=null;
            Int32 foundid;

            typeToReturn? returnedValue=default(typeToReturn) ;

            //select query to get field info to display
            switch (query) 
            {
                case 1:
                    selectedQuery = "select moduleid  from " + table + " where moduleid=" + startIDValue + ";";
                    break;
                case 2:
                    selectedQuery = "select moduleCode  from " + table + " where moduleid=" + startIDValue + ";";
                    break;
                case 3:
                    selectedQuery = "select moduleName  from " + table + " where moduleid=" + startIDValue + ";";
                    break;
                case 4:
                    selectedQuery = "select moduleCredits  from " + table + " where moduleid=" + startIDValue + ";";
                    break;
                case 5:
                    selectedQuery = "select totalModulehours_per_week  from " + table + " where moduleid=" + startIDValue + ";";

                    break;
                case 6:
                    selectedQuery = "select numberOfSemesterWeeks  from " + table + " where moduleid=" + startIDValue + ";";

                    break;
                case     7:
                    selectedQuery = "select StudyDay  from " + table + " where moduleid=" + startIDValue + ";";
                    break;

                case 8:
                    selectedQuery = "select requiredHours  from " + table + " where moduleid=" + startIDValue + ";";
                    break;
                case 9:
                    selectedQuery = "select startDate  from " + table + " where moduleid=" + startIDValue + ";";

                    break;
                case 10:
                    selectedQuery = "select hourStudied  from " + table + " where moduleid=" + startIDValue + ";";

                    break;
                case 11:
                    selectedQuery = "select sessiondate  from " + table + " where moduleid=" + startIDValue + ";";

                    break;

            }

            command = new MySqlCommand(selectedQuery, connection);
            returnedValue = (typeToReturn)command.ExecuteScalar();//error if null
            return returnedValue;
        }

    }

    public class FieldScanner
    {
        //class is involved when creating a module and adding a session
        public List<string> moduleCodes { get; set; }
        public List<string> moduleNames { get; set; }

        public FieldScanner() 
        {
            moduleCodes = new List<string>();
            moduleNames = new List<string>();
        }

        //function calculation self study hours required
        public int calculateSelfStudyHours(int modulesCredits, int numberOfWeeks, int hourPerWeek)
        {
            //breakdown of how formula variables should interact
            int SelfStudyHours = ((modulesCredits * 10) / numberOfWeeks) - hourPerWeek;

            return SelfStudyHours;
        }


        //Function uses LINQ check modules, to avoid studying non-existent modules
        public Boolean moduleExists(String moduleName)
        {
            //variable is returned and signals if a module exists
            Boolean codeExists = false;

            //Usage of LINQ  to create a subset of existing modules
            var item = from element in this.moduleNames
                       where moduleNames.Contains(moduleName)
                       select element;

            int counter = 0;
            //loop counts each existing module
            foreach (var itemfound in item)
            {
                counter++;
            }

            //if statement determines boolean result if counter returns with atleast 1 existing module
            if (counter != 0)
            {
                codeExists = true;
            }
            else
            {
                codeExists = false;
            }

            return codeExists;
        }

        //Function uses LINQ to check module existence, to help when updating study hours
        public Boolean moduleCodeExists(String moduleCode)
        {
            Boolean codeExists = false;

            //Usage of LINQ  to create a subset of existing module codes 
            var item = from element in this.moduleCodes
                       where moduleCodes.Contains(moduleCode)
                       select element;

            int counter = 0;

            //loop counts existing module code
            foreach (var itemfound in item)
            {
                counter++;
            }


            if (counter != 0)
            {
                codeExists = true;
            }
            else
            {
                codeExists = false;
            }

            return codeExists;
        }

        //function uses LINQ to help check data validity within fields
        public Boolean hasLetters(string wordSubject)
        {
            //store the conclusion of an entered string 
            Boolean hasLetter;

            //stores the characters to be searched in a string 
            string[] letters =
                {"q","w","e","r","t","y","u","i","o","p","a",
                 "s","d","f","g","h","j","k","l","z","x","c",
                 "v","b","n","m","~","!","@","#","$","%","^",
                 "&","*","(",")","_","+","=","-","{","}","[",
                 "]","|","/","?" };

            //Usage of LINQ  to create a subset of found letters in a integer only string
            var item = from element in letters
                       where wordSubject.Contains(element)
                       select element;
            
            int counter = 0;

            //loop counts existing module code
            foreach (var itemfound in item)
            {

                counter++;

            }

            //if statement determines boolean result, if counter returns with
            //atleast 1 existing letters it returns true
            if (counter != 0)
            {
                hasLetter = true;
            }
            else
            {
                hasLetter = false;
            }
            return hasLetter;
        }
    }

    public class encrytor
    {
        //class hashes a user's password 

        //function converts a password to a hash
        public  string ToSHA256(string StringToHash)
        {

            using var sha256 = SHA256.Create();
            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(StringToHash));

            var sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                sb.Append(bytes[i].ToString("x2"));
            }

            return sb.ToString();
        }
    }

    public class dateGenerator
    {
        //class generates a date to demontrate the notification feature

        
        public List<int> days { get; set; }
        public List<string> months { get; set; }
        public List<string> wDay { get; set; }
        public int Year { get; set; }

        public Random randomDay { get; set; }
        public Random randomMonth { get; set; }

        public string createdDate { get; set; }
        public string createdDay { get; set; }
        public string createdMonth { get; set; }
        public string createdWeekDay { get; set; }

        public dateGenerator() 
        {
          days = new List<int>();
          months = new List<string>();
          wDay = new List<string>();
          Year = 2024;

          randomDay = new Random();
          randomMonth = new Random();

          createdDate = null;
          createdDay = null;
          createdMonth = null;
          createdWeekDay = null;
    }

        //function sets the months to be dealt with
        public void fillMonths()
        {
            months.Add("January");
            months.Add("February");
            months.Add("March");
            months.Add("April");
            months.Add("May");
            months.Add("June");
            months.Add("July");
            months.Add("August");
            months.Add("September");
            months.Add("October");
            months.Add("November");
            months.Add("December");


            //for displaying all days
            int runs = 0;

            for (runs = 0; runs < 12;)
            {

                //Console.WriteLine(months[runs]);
                runs++;
            }
        }

        //function sets all weekdays to be dealt with
        public void fillWeekdays()
        {
            wDay.Add("Monday");
            wDay.Add("Tuesday");
            wDay.Add("Wednesday");
            wDay.Add("Thursday");
            wDay.Add("Friday");
            wDay.Add("Saturday");
            wDay.Add("Sunday");


            int runs = 0;

            //for displaying all days
            for (runs = 0; runs < 12;)
            {
                runs++;
            }
        }

        //function sets all month days to be dealt with
        public void fillDays()
        {
            int runs = 0;

            for (runs = 0; runs < 31;)
            {
                days.Add(runs + 1);
                runs++;
            }
        }

        //function creates a date that will used for the notification feature
        public void createDate()
        {
            fillDays();
            fillMonths();
            fillWeekdays();
            int rDay = randomDay.Next(31);
            int rWeekDay = randomDay.Next(7);
            int rMonth = randomMonth.Next(12);

            //Console.WriteLine(days[rDay] +" " + months[rMonth] +" "+Year+ ", "+ wDay[rWeekDay]);

            createdDay = days[rDay].ToString();
            createdMonth = months[rMonth];
            createdWeekDay = wDay[rWeekDay];


            createdDate = days[rDay] + ", " + months[rMonth] + ", " + Year + ", " + wDay[rWeekDay];
        }

        //function update the date_ table with a created date
        public void updpateDates(MySqlCommand command, string date, string studyDay, MySqlConnection connection) 
        {
            command = new MySqlCommand("update Date_ set fullDate='" + date + "';", connection);
            command.ExecuteNonQuery();

            command = new MySqlCommand("update Date_ set weekday='" + studyDay + "';", connection);
            command.ExecuteNonQuery();

        }

        //function gets the table of logged in user- OVERLOADED!
        public string getTable(MySqlCommand command, MySqlConnection connection)
        {
            string tableName = "select tableName from activeTable;";
            command = new MySqlCommand(tableName, connection);
            if (tableName != null) 
            {
                tableName = (string)command.ExecuteScalar();

            }

            return tableName;
        }

        //function returns a subject that falls on a particular study week day
        public string getReleventSubject(MySqlCommand command,dateGenerator dateGeneratorInstance, string studyDay, MySqlConnection connection)
        {
            string ?releventSubject=null;
            string activeTable = dateGeneratorInstance.getTable(command, connection);

            if (activeTable != "none")
            {
                command = new MySqlCommand("select moduleName from " + activeTable + " where StudyDay='" + studyDay + "';", connection);
                releventSubject = (string)command.ExecuteScalar();

                if (releventSubject == null || releventSubject == "")
                {
                    releventSubject = "nothing";
                }
            }
            else 
            {
                releventSubject = "";
            }

            return releventSubject;
        }
    }


    
}