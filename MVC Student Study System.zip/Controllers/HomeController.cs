﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using St10231624_PROG6212_POE_Part3.Models;
using System.Diagnostics;
using CustomClassLibrary;

namespace St10231624_PROG6212_POE_Part3.Controllers
{
    public class HomeController : Controller
    {
     
        private const string ConnectionString = "Server = localhost; Database= part2base; Uid=root; Pwd=";
        private MySqlConnection connection;

        private registrar registrarInstance;
        private encrytor encrytorInstance;
        private loginRunner loginMan;
        private moduleLogger moduleLoggerInstance;
        private sessionLogger sessionLoggerInstance;
        private modulesReader modulesReaderInstance;
        private FieldScanner fieldScannerInstance;
        private dateGenerator dateGeneratorInstance;

        private readonly ILogger<HomeController> _logger;
        private string moduleTable;
        private string sessionsTable;


        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            connection = new MySqlConnection(ConnectionString);

            registrarInstance=new registrar();
            encrytorInstance = new encrytor();
            loginMan = new loginRunner();
            moduleLoggerInstance=new moduleLogger();
            sessionLoggerInstance=new sessionLogger();
            modulesReaderInstance=new modulesReader();
            fieldScannerInstance=new FieldScanner();
            dateGeneratorInstance = new dateGenerator();

            connection.Open();

            //table to track new users
            MySqlCommand command = new MySqlCommand("create table if not exists users(userid int  primary key auto_increment, username varchar(20), password_ varchar(100), tableName varchar(100));", connection);
            command.ExecuteNonQuery();

            //table to target the right table on a user logging in
            command = new MySqlCommand("create table if not exists activeTable(tableName varchar(100));", connection);
            command.ExecuteNonQuery();

            //remove table in order to add it afresh
            command = new MySqlCommand("drop table if exists date_;", connection);
            command.ExecuteNonQuery();

            //create table to store the date for study notification
            command = new MySqlCommand("create table if not exists Date_(fullDate varchar(100) default 'rdate', weekday varchar(100) default 'rday');", connection);
            command.ExecuteNonQuery();

            //add data to date table
            command = new MySqlCommand("insert into date_ values('rdate', 'weekday');", connection);
            command.ExecuteNonQuery();

            //count activeTable elements
            command = new MySqlCommand("select count(*) from activeTable;", connection);

            //assign count so that its value is used
            long rows=(Int64)command.ExecuteScalar();
            
            //insert if there is no table set to target on login, else update- this is done in another function
            if (rows < 1) 
            {
                command = new MySqlCommand("insert into activeTable(tableName)values('none');", connection);
                command.ExecuteNonQuery();
            }
            
            connection.Close();
        }


        //register user
        public IActionResult addRegistration(String Name, String Surname, String Username, String Password)
        {
            Boolean canLogin = false;
            string? viewName = null;

            //take data and check if data is correct
            canLogin=registrarInstance.registerUser( Name,  Surname,  Username,  Password, encrytorInstance, connection);

            //if data is correct, send to the right page
            if (canLogin == false)
            {
                ViewData["regStatus"] = "Please fill all fields";
                viewName = "addRegistration";
            }
            else if (canLogin == true)
            {
                viewName = "loginApp";
            }

            return View(viewName);
        }


        public IActionResult loginApp(String Username, String Password)
        {
            connection.Open();

            //create a date we can use in the notification feature
            dateGeneratorInstance.createDate();
            
            //assign the created date to a variable we can use
            string date = dateGeneratorInstance.createdDate.ToString();

            //assign the day of the date to a variable so that we check which module falls on that daty
            string studyDay = dateGeneratorInstance.createdWeekDay;
            MySqlCommand? command = null;

            //add the created date into the date_ table 
            dateGeneratorInstance.updpateDates(command, date, studyDay, connection);
            //compare the weekday with the day on a module and show result on the page notification system
            ViewData["date"] = date;
            ViewData["module"] = dateGeneratorInstance.getReleventSubject(command, dateGeneratorInstance, studyDay, connection);

            //add date and day on database
            connection.Close();

            //set the page to view on successful login
            string? pageView = loginMan.loginUser( Username,  Password,  encrytorInstance,  connection);

            return View(pageView);
        }


        //run the home page
        public IActionResult Index(String? moduleCode, String moduleName, String totalCredits, String HoursPerWeek, String weekdayStudy, String totalWeeks, String startDate)
        {
            connection.Open();

            //create a date we can use in the notification feature
            dateGeneratorInstance.createDate();

            //assign the created date to a variable we can use
            string date = dateGeneratorInstance.createdDate.ToString();

            //assign the day of the date to a variable so that we check which module falls on that daty
            string studyDay = dateGeneratorInstance.createdWeekDay;
            MySqlCommand ?command=null;

            //add the created date into the date_ table 
            dateGeneratorInstance.updpateDates(command, date, studyDay, connection);

            //compare the weekday with the day on a module
            ViewData["date"] = date;
            ViewData["module"] = dateGeneratorInstance.getReleventSubject(command, dateGeneratorInstance, studyDay, connection);

            connection.Close();

            //check if fields are not empty
            if (totalCredits != null && HoursPerWeek != null && totalWeeks != null) 
            {
                Boolean credits = fieldScannerInstance.hasLetters(totalCredits);
                Boolean hourAWeek = fieldScannerInstance.hasLetters(HoursPerWeek);
                Boolean allWeeks = fieldScannerInstance.hasLetters(totalWeeks);

                //check if number fields do not have letters or special symbols
                if (credits == false && allWeeks == false && hourAWeek == false)
                {
                    moduleLoggerInstance.addModule(moduleCode, moduleName, totalCredits, HoursPerWeek, weekdayStudy, totalWeeks, startDate, connection);
                }
            }
            

            return View();
        }


        //get info about study sessions
        public IActionResult getSessionData(String studiedModule, String studiedHours, String dateStudied)
        {
            if (studiedHours != null)
            {
                Boolean studyPeried = fieldScannerInstance.hasLetters(studiedHours);

                //check if field only have numerical characters
                if (studyPeried == false)
                {
                    sessionLoggerInstance.addSession(studiedModule, studiedHours, dateStudied, connection);
                }
            }
            

            return View();
        }


        //show all module data
        public IActionResult showSubjects()
        {

            connection.Open();

           
            MySqlCommand ?command = null;

            //getting table of logged in user
            String tableName = modulesReaderInstance.getActiveTable(command,connection);
            //get all ids in a loop
            int runs = 0;

            //set the module id of the first module
            int startIDValue = 1;

            //get number of modules of the logged in user's table
            command = new MySqlCommand("select count(*)  from "+tableName+";", connection);

            //assign the value for use
            long numberOfRecords = modulesReaderInstance.getNumberOfRecords(command, tableName, connection);

            //send  value to cshtml to use on a loop that shows records
            ViewData["numberOfRecords"] = numberOfRecords;
            
            //loop to send data on each field, for each record on the cshtml page for display
            while (runs!=numberOfRecords) 
            {   
                ViewData[runs.ToString()] = modulesReaderInstance.runCommand<Int32>(command, tableName, startIDValue, connection, 1);
                ViewData["moduleCode" + runs.ToString()] = modulesReaderInstance.runCommand<string>(command, tableName, startIDValue, connection, 2);
                ViewData["moduleName" + runs.ToString()] = modulesReaderInstance.runCommand<string>(command, tableName, startIDValue, connection, 3);
                ViewData["moduleCredits" + runs.ToString()] = modulesReaderInstance.runCommand<int>(command, tableName, startIDValue, connection, 4);
                ViewData["totalModulehours_per_week" + runs.ToString()] = modulesReaderInstance.runCommand<int>(command, tableName, startIDValue, connection, 5);               
                ViewData["numberOfSemesterWeeks" + runs.ToString()] = modulesReaderInstance.runCommand<int>(command, tableName, startIDValue, connection, 6);
                ViewData["StudyDay" + runs.ToString()] = modulesReaderInstance.runCommand<string>(command, tableName, startIDValue, connection, 7);

                ViewData["requireHours" + runs.ToString()] = modulesReaderInstance.runCommand<int>(command, tableName, startIDValue, connection, 8);                
                ViewData["startDate" + runs.ToString()] = modulesReaderInstance.runCommand<string>(command, tableName, startIDValue, connection, 9);
                ViewData["hourStudied" + runs.ToString()] = modulesReaderInstance.runCommand<int>(command, tableName, startIDValue, connection, 10);
                ViewData["sessiondate" + runs.ToString()] = modulesReaderInstance.runCommand<string>(command, tableName, startIDValue, connection, 11);

                startIDValue++;
                runs++;
            }

            connection.Close();
            return View();
        }

        private IActionResult registerUser(String Name, String Surname, String Username, String Password)
        {
            return View();
        }

        private ActionResult getLoginData()
        {
            return View();
        }

        public IActionResult getModuleData()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        
        //Handle Errors
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}